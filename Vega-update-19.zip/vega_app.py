"""
Vega - Hemanth's personal assistant (app window).

Start it by double-clicking the Vega shortcut on your desktop,
or in PowerShell:   cd C:\\CloudLab\\mybot   then   python vega_app.py
"""

import os
import queue
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import json
import webbrowser
from datetime import datetime

import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vega_core import IS_WINDOWS, NO_WINDOW, ReminderClock, Vega, here, save_config_value  # noqa: E402
from vega_voice import Ears, Mouth, WakeListener, beep, shorten_for_speech  # noqa: E402
import vega_voice  # noqa: E402
import vega_security as sec  # noqa: E402

C = dict(bg="#0D1319", panel="#141C25", line="#223040", ink="#E3EAF1", muted="#8594A3", accent="#8FB4FF",
         you="#F0C674", ok="#6FD19E", warn="#E6B15C", bad="#F08A7E", entry="#1A2430", btn="#1F2B39", btn_hi="#2A3A4D")
UI_FONT = "Segoe UI" if IS_WINDOWS else "DejaVu Sans"
F = (UI_FONT, 11)
F_SMALL = (UI_FONT, 9)
F_BOLD = (UI_FONT, 11, "bold")
F_TITLE = (UI_FONT, 18, "bold")
PORT = 47631  # used to make sure only one Vega runs at a time
URL_RE = re.compile(r"https?://[^\s)]+")
LOG_FILE = "chat_log.jsonl"   # everything you and Vega said, shown again when you reopen her
STAMP_RE = re.compile(r"^\[\d{1,2} \w{3} \d{4}, \d{1,2}:\d{2} [AP]M\]\s*")


# ---------------------------------------------------------------- self-repair

NEEDED = {"requests": "requests", "psutil": "psutil", "pypdf": "pypdf", "docx": "python-docx",
          "ollama": "ollama", "faster_whisper": "faster-whisper", "sounddevice": "sounddevice", "numpy": "numpy"}


def missing_packages():
    import importlib.util
    return [pip for mod, pip in NEEDED.items() if importlib.util.find_spec(mod) is None]


def pip_python():
    """The Python that is running Vega right now (python.exe, not pythonw.exe, for pip)."""
    exe = sys.executable
    if exe.lower().endswith("pythonw.exe"):
        alt = exe[:-len("pythonw.exe")] + "python.exe"
        if os.path.exists(alt):
            return alt
    return exe


# ---------------------------------------------------------------- chat history

def log_message(who, text):
    try:
        with open(here(LOG_FILE), "a", encoding="utf-8") as f:
            f.write(json.dumps({"t": datetime.now().isoformat(timespec="seconds"), "who": who, "text": text[:6000]},
                               ensure_ascii=False) + "\n")
    except OSError:
        pass


def read_log(last=40):
    """The last messages from chat_log.jsonl. The first time, bring in the old chats from memory.json."""
    path = here(LOG_FILE)
    if not os.path.exists(path):
        try:
            with open(here("memory.json"), "r", encoding="utf-8") as f:
                old = json.load(f)
            with open(path, "w", encoding="utf-8") as f:
                for m in old if isinstance(old, list) else []:
                    if isinstance(m, dict) and m.get("content") and m.get("role") in ("user", "assistant"):
                        f.write(json.dumps({"t": "", "who": "you" if m["role"] == "user" else "vega",
                                            "text": STAMP_RE.sub("", m["content"])}, ensure_ascii=False) + "\n")
        except (OSError, ValueError):
            return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except OSError:
        return []
    if len(lines) > 3000:  # keep the file small
        lines = lines[-1500:]
        with open(path, "w", encoding="utf-8") as f:
            f.writelines(lines)
    out = []
    for line in lines[-last:]:
        try:
            out.append(json.loads(line))
        except ValueError:
            pass
    return out


def nice_time(iso):
    try:
        dt = datetime.fromisoformat(iso)
    except (TypeError, ValueError):
        return ""
    t = dt.strftime("%I:%M %p").lstrip("0")
    if dt.date() == datetime.now().date():
        return t
    return dt.strftime("%d %b, ") + t


# ---------------------------------------------------------------- shortcuts

def pythonw():
    p = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    return p if os.path.exists(p) else sys.executable


def startup_shortcut_path():
    return os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs", "Startup", "Vega.lnk")


def desktop_folder():
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders") as k:
            return os.path.expandvars(winreg.QueryValueEx(k, "Desktop")[0])
    except Exception:
        return os.path.join(os.path.expanduser("~"), "Desktop")


def make_shortcut(lnk):
    wscript = os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "System32", "wscript.exe")
    env = dict(os.environ, VEGA_LNK=lnk, VEGA_PYW=wscript, VEGA_SCRIPT=here("Start Vega.vbs"), VEGA_DIR=here())
    ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:VEGA_LNK);"
          "$s.TargetPath=$env:VEGA_PYW;$s.Arguments='\"'+$env:VEGA_SCRIPT+'\"';"
          "$s.WorkingDirectory=$env:VEGA_DIR;$s.Description='Vega - personal assistant';$s.Save()")
    subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps],
                   env=env, creationflags=NO_WINDOW, timeout=30, check=True)


def open_path(path):
    if IS_WINDOWS:
        os.startfile(path)
    else:
        webbrowser.open("file://" + path)


# ---------------------------------------------------------------- the window

class App:
    def __init__(self, root, server):
        self.root = root
        self.vega = Vega()
        cfg = self.vega.cfg
        self.mouth = Mouth(rate=cfg.get("speech_rate", 1), voice=cfg.get("voice", "female"))
        self.ears = Ears(cfg.get("whisper_model", "small.en"), cfg.get("wake_model", "base.en"))
        vega_voice.LEARNED.update(str(w).lower() for w in cfg.get("wake_variants", []) if w)
        self.ears.telugu = bool(cfg.get("understand_telugu", False))
        self.mouth.telugu = bool(cfg.get("speak_telugu", False))
        self.mouth.telugu_voice = cfg.get("telugu_voice", "te-IN-ShrutiNeural")
        self.mouth.on_error = lambda m: self.ui.put(lambda: self.system(m, "warn"))
        self.ears.telugu_model_name = cfg.get("telugu_model", "small")
        self.ears.hint = self.vega.speech_hint()
        threading.Thread(target=self.vega.refresh_app_index, daemon=True).start()  # learn every installed app
        self.ui = queue.Queue()
        self.busy = False
        self.listening = False
        self.listen_stop = None
        self.streaming = False
        self.phone = None
        self.told_about_close = False
        self.locked = False
        self.lock_frame = None
        self.pending_briefing = False
        self.pin_fails = 0
        self.recent_scores = []  # last voice matches, shown in Voice strictness
        self.pin_wait_until = 0.0
        self.last_activity = time.time()
        self.voice = sec.VoiceID()

        self.build()
        threading.Thread(target=self.accept_other_instances, args=(server,), daemon=True).start()

        ReminderClock(self.vega, lambda text: self.ui.put(lambda: self.on_reminder(text)),
                      on_briefing=lambda: self.ui.put(self.auto_briefing)).start()
        self.wake = WakeListener(
            self.ears,
            on_wake=lambda: self.ui.put(self.on_wake),
            on_command=lambda text, audio=None: self.ui.put(lambda: self.voice_gate(text, audio)),
            is_busy=lambda: self.busy or self.listening or self.mouth.busy() or (self.locked and not sec.voice_unlock_ready()),
            on_error=lambda m: self.ui.put(lambda: self.system(m, "warn")))
        self.wake.start()
        self.wake.set_enabled(bool(self.wake_var.get()))
        self.start_phone()

        self.show_history()
        self.greet()
        self.repair_if_needed()
        for ev in ("<KeyPress>", "<ButtonPress>"):
            self.root.bind_all(ev, lambda e: setattr(self, "last_activity", time.time()), add="+")
        if sec.has_pin():
            self.lock()
        self.root.after(30000, self.check_idle)
        threading.Thread(target=self.check_ollama, daemon=True).start()
        self.root.after(50, self.poll)

    # ---------------- layout
    def button(self, parent, text, cmd, **kw):
        b = tk.Button(parent, text=text, command=cmd, font=kw.pop("font", F), bg=kw.pop("bg", C["btn"]), fg=kw.pop("fg", C["ink"]),
                      activebackground=C["btn_hi"], activeforeground=C["ink"], relief="flat", bd=0,
                      padx=kw.pop("padx", 12), pady=kw.pop("pady", 6), cursor="hand2", **kw)
        return b

    def build(self):
        r = self.root
        r.title("Vega")
        r.geometry("540x780")
        r.minsize(380, 480)
        r.configure(bg=C["bg"])
        r.protocol("WM_DELETE_WINDOW", self.on_close)

        top = tk.Frame(r, bg=C["bg"])
        top.pack(fill="x", padx=16, pady=(14, 6))
        tk.Label(top, text="Vega", font=F_TITLE, bg=C["bg"], fg=C["ink"]).pack(side="left")
        self.dot = tk.Canvas(top, width=12, height=12, bg=C["bg"], highlightthickness=0)
        self.dot.pack(side="left", padx=(12, 6), pady=(6, 0))
        self.dot_id = self.dot.create_oval(2, 2, 11, 11, fill=C["ok"], outline="")
        self.status_lbl = tk.Label(top, text="Ready", font=F_SMALL, bg=C["bg"], fg=C["muted"])
        self.status_lbl.pack(side="left", pady=(6, 0))

        menu_btn = tk.Menubutton(top, text="Menu ▾", font=F_SMALL, bg=C["btn"], fg=C["ink"], activebackground=C["btn_hi"],
                                 activeforeground=C["ink"], relief="flat", padx=10, pady=4, cursor="hand2")
        menu = tk.Menu(menu_btn, tearoff=0, bg=C["panel"], fg=C["ink"], activebackground=C["btn_hi"], activeforeground=C["ink"])
        self.startup_var = tk.BooleanVar(value=os.path.exists(startup_shortcut_path()))
        menu.add_checkbutton(label="Start with Windows", variable=self.startup_var, command=self.toggle_startup)
        menu.add_command(label="Create desktop shortcut", command=self.desktop_shortcut)
        menu.add_command(label="Connect phone (Telegram)…", command=self.connect_phone)
        menu.add_separator()
        menu.add_command(label="Open documents folder", command=lambda: open_path(self.vega.doc_folder()))
        menu.add_command(label="Open diary folder", command=lambda: open_path(here("diary")))
        menu.add_command(label="Edit settings (config.json)", command=self.edit_settings)
        menu.add_command(label="Clear chat", command=self.clear_chat)
        menu.add_separator()
        menu.add_command(label="Set or change PIN…", command=self.set_pin)
        menu.add_command(label="Remove PIN", command=self.remove_pin)
        menu.add_command(label="Lock Vega now", command=self.lock)
        lock_menu = tk.Menu(menu, tearoff=0, bg=C["panel"], fg=C["ink"], activebackground=C["btn_hi"], activeforeground=C["ink"])
        self.lock_min_var = tk.IntVar(value=sec.lock_minutes())
        for label, n in (("After 5 minutes", 5), ("After 15 minutes", 15), ("After 30 minutes", 30),
                         ("After 1 hour", 60), ("After 3 hours", 180), ("Never (only when I start)", 0)):
            lock_menu.add_radiobutton(label=label, value=n, variable=self.lock_min_var,
                                      command=lambda n=n: self.set_autolock(n))
        menu.add_cascade(label="Auto-lock", menu=lock_menu)
        self.brain_menu = tk.Menu(menu, tearoff=0, bg=C["panel"], fg=C["ink"], activebackground=C["btn_hi"],
                                  activeforeground=C["ink"], postcommand=self.fill_brain_menu)
        menu.add_cascade(label="Brain (AI model)", menu=self.brain_menu)
        menu.add_separator()
        menu.add_command(label="Set up my voice…", command=self.setup_voice)
        menu.add_command(label="Voice strictness…", command=self.voice_strictness)
        menu.add_command(label="Teach me your “Hey Vega”…", command=self.teach_wake)
        self.telugu_var = tk.BooleanVar(value=bool(self.vega.cfg.get("understand_telugu", False)))
        menu.add_checkbutton(label="Understand Telugu speech", variable=self.telugu_var, command=self.toggle_telugu)
        self.speak_te_var = tk.BooleanVar(value=bool(self.vega.cfg.get("speak_telugu", False)))
        menu.add_checkbutton(label="Speak in Telugu", variable=self.speak_te_var, command=self.toggle_speak_telugu)
        self.voice_only_var = tk.BooleanVar(value=sec.voice_only())
        menu.add_checkbutton(label="Only obey my voice", variable=self.voice_only_var, command=self.toggle_voice_only)
        menu.add_separator()
        menu.add_command(label="Quit Vega", command=self.quit)
        menu_btn.configure(menu=menu)
        menu_btn.pack(side="right")

        toggles = tk.Frame(r, bg=C["bg"])
        toggles.pack(fill="x", padx=16)
        self.voice_var = tk.IntVar(value=1 if self.vega.cfg.get("voice_on", True) else 0)
        self.wake_var = tk.IntVar(value=1 if self.vega.cfg.get("wake_word_on", False) else 0)
        for text, var, cmd in (("Speak answers", self.voice_var, self.toggle_voice),
                               ("Listen for “Hey Vega”", self.wake_var, self.toggle_wake)):
            tk.Checkbutton(toggles, text=text, variable=var, command=cmd, font=F_SMALL, bg=C["bg"], fg=C["muted"],
                           selectcolor=C["panel"], activebackground=C["bg"], activeforeground=C["ink"],
                           highlightthickness=0, bd=0, cursor="hand2").pack(side="left", padx=(0, 14))

        quick = tk.Frame(r, bg=C["bg"])
        quick.pack(fill="x", padx=16, pady=(10, 8))
        items = [("Today's task", "what's my task today"), ("I finished it", "I finished today's task"),
                 ("Progress", "my progress"), ("Weather", "weather"), ("News", "news"),
                 ("My tasks", "my tasks"), ("Reminders", "my reminders"), ("Laptop", "laptop status"),
                 ("Diary", "open my diary"), ("Help", "help")]
        for i, (label, cmd) in enumerate(items):
            b = self.button(quick, label, lambda c=cmd: self.send(c), font=F_SMALL, padx=6, pady=5)
            b.grid(row=i // 5, column=i % 5, sticky="ew", padx=3, pady=3)
        for col in range(5):
            quick.columnconfigure(col, weight=1)

        box = tk.Frame(r, bg=C["panel"], highlightbackground=C["line"], highlightthickness=1)
        box.pack(fill="both", expand=True, padx=16)
        self.text = tk.Text(box, wrap="word", font=F, height=10, bg=C["panel"], fg=C["ink"], relief="flat", bd=0, padx=14, pady=12,
                            insertbackground=C["ink"], selectbackground=C["btn_hi"], spacing1=2, spacing3=2, cursor="arrow")
        sb = tk.Scrollbar(box, command=self.text.yview, bg=C["panel"], troughcolor=C["panel"], relief="flat", bd=0)
        self.text.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.text.pack(side="left", fill="both", expand=True)
        self.text.tag_configure("who_you", foreground=C["you"], font=F_BOLD, spacing1=12)
        self.text.tag_configure("who_vega", foreground=C["accent"], font=F_BOLD, spacing1=12)
        self.text.tag_configure("body", foreground=C["ink"], lmargin1=2, lmargin2=2)
        self.text.tag_configure("muted", foreground=C["muted"], font=F_SMALL, spacing1=8)
        self.text.tag_configure("stamp", foreground=C["muted"], font=F_SMALL)
        self.text.tag_configure("divider", foreground=C["muted"], font=F_SMALL, justify="center", spacing1=14, spacing3=4)
        self.text.tag_configure("warn", foreground=C["warn"], font=F_SMALL, spacing1=8)
        self.text.tag_configure("link", foreground=C["accent"], underline=True)
        self.text.tag_configure("code", font=("Consolas" if IS_WINDOWS else "DejaVu Sans Mono", 10), foreground=C["ok"])
        self.text.tag_bind("link", "<Button-1>", self.click_link)
        self.text.tag_bind("link", "<Enter>", lambda e: self.text.configure(cursor="hand2"))
        self.text.tag_bind("link", "<Leave>", lambda e: self.text.configure(cursor="arrow"))
        self.text.bind("<Key>", lambda e: None if (e.state & 4 and e.keysym.lower() in ("c", "a")) else "break")

        bottom = tk.Frame(r, bg=C["bg"])
        bottom.pack(fill="x", padx=16, pady=(10, 4))
        self.entry = tk.Entry(bottom, font=F, bg=C["entry"], fg=C["ink"], insertbackground=C["ink"], relief="flat",
                              highlightthickness=1, highlightbackground=C["line"], highlightcolor=C["accent"])
        self.entry.pack(side="left", fill="x", expand=True, ipady=8)
        self.entry.bind("<Return>", lambda e: self.on_send())
        self.mic_btn = self.button(bottom, "Mic", self.on_mic, bg=C["btn"])
        self.mic_btn.pack(side="left", padx=(8, 0))
        self.button(bottom, "Attach", self.on_attach).pack(side="left", padx=(6, 0))
        self.send_btn = self.button(bottom, "Send", self.on_send, bg=C["accent"], fg=C["bg"], font=F_BOLD)
        self.send_btn.pack(side="left", padx=(6, 0))
        tk.Label(r, text="Enter to send  ·  Mic to talk  ·  Say “help” to see everything I can do",
                 font=F_SMALL, bg=C["bg"], fg=C["muted"]).pack(pady=(0, 10))
        self.entry.focus_set()

    # ---------------- chat display
    def _insert(self, text, tags):
        self.text.insert("end", text, tags)

    def _insert_body(self, text):
        text = re.sub(r"```[a-zA-Z]*\n?", "`", text)
        for n, chunk in enumerate(text.split("`")):
            if n % 2:  # inside `backticks`: show as a command
                self._insert(chunk, ("body", "code"))
                continue
            pos = 0
            for m in URL_RE.finditer(chunk):
                self._insert(chunk[pos:m.start()], ("body",))
                self._insert(m.group(0), ("body", "link"))
                pos = m.end()
            self._insert(chunk[pos:], ("body",))

    def _name(self, who, when=None):
        tag = "who_you" if who in ("you", "phone") else "who_vega"
        label = {"you": "You", "phone": "You (phone)"}.get(who, "Vega")
        self.text.insert("end", label, (tag,))
        stamp = nice_time(when) if when is not None else nice_time(datetime.now().isoformat())
        if stamp:
            self.text.insert("end", "   " + stamp, (tag, "stamp"))
        self.text.insert("end", "\n", (tag,))

    def add_message(self, who, text, when=None, save=True):
        self._name(who, when)
        self._insert_body(text.strip() + "\n")
        self.text.see("end")
        if save:
            log_message(who, text)

    def show_history(self):
        old = read_log()
        if not old:
            return
        self._insert("Earlier\n", ("divider",))
        for m in old:
            self.add_message(m.get("who", "vega"), m.get("text", ""), when=m.get("t", ""), save=False)
        self._insert("Now\n", ("divider",))

    def system(self, text, level="muted"):
        self._insert(text.strip() + "\n", (level,))
        self.text.see("end")

    def stream_update(self, text):
        if not self.streaming:
            self.streaming = True
            self._name("vega")
            self.text.mark_set("stream", "end-1c")
            self.text.mark_gravity("stream", "left")
        self.text.delete("stream", "end-1c")
        self._insert(text, ("body",))
        self.text.see("end")

    def click_link(self, event):
        rng = self.text.tag_prevrange("link", "current+1c")
        if rng:
            webbrowser.open(self.text.get(*rng))

    def set_status(self, text, color="ok"):
        self.status_lbl.configure(text=text)
        self.dot.itemconfigure(self.dot_id, fill=C[color])

    # ---------------- sending
    def on_send(self):
        if self.busy:
            self.vega.stop()
            self.mouth.stop()
            return
        text = self.entry.get().strip()
        if not text:
            return
        self.entry.delete(0, "end")
        self.send(text)

    def send(self, text, spoken=False):
        if self.locked:
            return
        self.last_activity = time.time()
        if self.busy:
            self.system("I'm still answering. Press Stop first.", "warn")
            return
        if re.sub(r"[^a-z ]", "", text.lower()).strip() in ("allow phone", "connect phone", "connect that phone", "connect my phone", "allow my phone"):
            self.add_message("you", text)
            if getattr(self, "pending_pair", None):
                self.allow_phone()
            else:
                self.connect_phone()
            return
        self.mouth.stop()
        self.add_message("you", text)
        self.ears.hint = self.vega.speech_hint()
        self.run_job(lambda on_token: self.vega.handle(text, on_token=on_token, spoken=spoken))

    def run_job(self, fn):
        self.busy = True
        self.streaming = False
        self.send_btn.configure(text="Stop")
        self.set_status("Thinking…", "accent")

        def on_token(t):
            self.ui.put(lambda t=t: self.stream_update(t))

        def work():
            try:
                result = fn(on_token)
            except Exception as e:
                result = {"text": f"Something went wrong: {e}", "say": "Something went wrong."}
            self.ui.put(lambda: self.finish(result))

        threading.Thread(target=work, daemon=True).start()

    def finish(self, result):
        text = result.get("text", "")
        if self.streaming:
            self.text.delete("stream", "end-1c")
            self._insert_body(text.strip() + "\n")
            self.text.see("end")
            log_message("vega", text)
        else:
            self.add_message("vega", text)
        self.streaming = False
        self.busy = False
        self.send_btn.configure(text="Send")
        used = result.get("model")
        if used and not self.vega._same(used, self.vega.cfg.get("model") or "vega") and not self.vega.diary_mode:
            self.set_status(f"Ready (that answer came from {used})", "ok")
        else:
            self.set_status("Diary open" if self.vega.diary_mode else "Ready", "you" if self.vega.diary_mode else "ok")
        if self.voice_var.get():
            self.mouth.say(shorten_for_speech(result.get("say") or text))

    # ---------------- microphone
    def on_mic(self):
        if self.locked:
            return
        if self.listening:
            if self.listen_stop:
                self.listen_stop.set()
            return
        if self.busy:
            self.system("Wait until I finish answering, or press Stop.", "warn")
            return
        self.mouth.stop()
        self.listening = True
        self.listen_stop = threading.Event()
        self.wake.paused.set()
        self.mic_btn.configure(text="Done", bg=C["you"], fg=C["bg"])
        self.set_status("Listening… speak now (I stop when you stop)", "you")
        first_time = self.ears.main_model_name() not in self.ears._models
        if first_time:
            self.system("Loading speech recognition. The first time, it downloads about 500 MB, so wait a minute or two.")

        def work():
            text, err, audio = "", None, None
            try:
                self.ears.model(self.ears.main_model_name())
                audio = self.ears.listen_once(self.listen_stop)
                if audio is not None:
                    self.ui.put(lambda: self.set_status("Understanding…", "accent"))
                    text = self.ears.transcribe(audio)
            except Exception as e:
                err = str(e)
            self.ui.put(lambda: self.mic_done(text, err, audio))

        threading.Thread(target=work, daemon=True).start()

    def mic_done(self, text, err, audio=None):
        self.listening = False
        self.wake.paused.clear()
        self.mic_btn.configure(text="Mic", bg=C["btn"], fg=C["ink"])
        self.set_status("Ready")
        if err:
            self.system(f"Microphone problem: {err}", "warn")
        elif not text:
            self.system("I didn't hear anything. Press Mic and try again, a bit closer.")
        else:
            self.voice_gate(text, audio)

    def voice_gate(self, text, audio):
        """If 'Only obey my voice' is on, check it's Hemanth speaking before doing anything."""
        if self.locked:
            if audio is not None and sec.voice_unlock_ready():
                self.voice_unlock(audio, then_text=text)
            return
        if not (sec.voice_only() and audio is not None):
            self.send(text, spoken=True)
            return
        self.set_status("Checking it's you…", "accent")

        def work():
            try:
                score, err = self.voice.score(audio), None
            except Exception as e:
                score, err = None, str(e)
            self.ui.put(lambda: after(score, err))

        def after(score, err):
            self.set_status("Ready")
            if score is not None:
                self.note_score(score)
            if err:
                self.system(f"I couldn't check your voice ({err}), so I'm doing it anyway.", "warn")
                self.send(text, spoken=True)
            elif score < sec.voice_threshold():
                self.system(f"Heard “{text}”, but that didn't sound like Hemanth (voice match {score:.2f}, "
                            f"needs {sec.voice_threshold():.2f}). I ignored it.", "warn")
            else:
                self.send(text, spoken=True)

        threading.Thread(target=work, daemon=True).start()

    def on_wake(self):
        self.mouth.stop()
        self.set_status("Yes? I'm listening…", "you")

    # ---------------- documents
    def on_attach(self):
        if self.busy:
            return
        path = filedialog.askopenfilename(title="Choose a document for Vega",
                                          filetypes=[("Documents", "*.pdf *.docx *.txt *.md *.csv *.py *.sh *.yaml *.yml *.json *.log"),
                                                     ("All files", "*.*")])
        if not path:
            return
        folder = self.vega.doc_folder()
        name = os.path.basename(path)
        target = os.path.join(folder, name)
        try:
            if os.path.abspath(os.path.dirname(path)) != os.path.abspath(folder) and not os.path.exists(target):
                shutil.copy2(path, target)
                path = target
        except OSError:
            pass
        self.add_message("you", f"(attached {name})")

        def job(on_token):
            out = self.vega.load_document(path)
            if out.get("ask"):
                return self.vega.chat(out["ask"], on_token=on_token, shown=f"(attached {name})", instruction=out.get("instruction"))
            return out

        self.run_job(job)

    # ---------------- reminders
    def on_reminder(self, text):
        self.system(f"Reminder: {text}", "warn")
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.attributes("-topmost", True)
            self.root.after(1500, lambda: self.root.attributes("-topmost", False))
        except tk.TclError:
            pass
        beep("reminder")
        self.mouth.say("Hemanth, you have a reminder. Unlock me to see it." if self.locked else f"Hemanth, reminder: {text}")
        if self.phone:
            self.phone.send(f"Reminder: {text}")

    def auto_briefing(self):
        """The daily morning briefing: on screen, spoken, and sent to the phone."""
        def job(on_token):
            out = self.vega.morning_briefing()
            if self.phone:
                self.phone.send(out["text"])
            return out
        if self.locked:
            self.pending_briefing = True
            return
        if self.busy:
            self.root.after(30000, self.auto_briefing)
            return
        self.run_job(job)

    # ---------------- PIN lock
    def lock(self):
        if not sec.has_pin():
            self.system("Set a PIN first: Menu → Set or change PIN.")
            return
        if self.locked:
            return
        self.locked = True
        self.mouth.stop()
        if self.listen_stop:
            self.listen_stop.set()
        f = tk.Frame(self.root, bg=C["bg"])
        f.place(relx=0, rely=0, relwidth=1, relheight=1)
        inner = tk.Frame(f, bg=C["bg"])
        inner.place(relx=0.5, rely=0.42, anchor="center")
        tk.Label(inner, text="Vega", font=F_TITLE, bg=C["bg"], fg=C["ink"]).pack(pady=(0, 6))
        tk.Label(inner, text="Locked. Enter your PIN.", font=F, bg=C["bg"], fg=C["muted"]).pack(pady=(0, 12))
        self.pin_entry = tk.Entry(inner, show="•", font=(UI_FONT, 16), justify="center", width=12, bg=C["entry"], fg=C["ink"],
                                  insertbackground=C["ink"], relief="flat", highlightthickness=1,
                                  highlightbackground=C["line"], highlightcolor=C["accent"])
        self.pin_entry.pack(ipady=6)
        self.pin_entry.bind("<Return>", lambda e: self.try_unlock())
        self.button(inner, "Unlock", self.try_unlock, bg=C["accent"], fg=C["bg"], font=F_BOLD).pack(pady=12, fill="x")
        if sec.voice_unlock_ready():
            self.button(inner, "Unlock with my voice", lambda: self.voice_unlock()).pack(pady=(0, 10), fill="x")
            tk.Label(inner, text="Or just say “Hey Vega, it's Hemanth”.", font=F_SMALL, bg=C["bg"], fg=C["muted"]).pack()
        self.pin_msg = tk.Label(inner, text="", font=F_SMALL, bg=C["bg"], fg=C["warn"], wraplength=320, justify="center")
        self.pin_msg.pack(pady=(6, 0))
        tk.Label(inner, text="Reminders and your phone link keep working while I'm locked.", font=F_SMALL,
                 bg=C["bg"], fg=C["muted"]).pack(pady=(18, 0))
        self.lock_frame = f
        f.lift()
        self.set_status("Locked", "you")
        self.root.after(100, self.pin_entry.focus_set)

    def try_unlock(self):
        now = time.time()
        if now < self.pin_wait_until:
            self.pin_msg.configure(text=f"Too many wrong tries. Wait {int(self.pin_wait_until - now) + 1} seconds.")
            return
        pin = self.pin_entry.get()
        self.pin_entry.delete(0, "end")
        if sec.check_pin(pin):
            fv = getattr(self, "failed_voice", None)
            self.failed_voice = None
            self.unlock()
            if fv and time.time() - fv[0] < 120:
                threading.Thread(target=lambda: self.voice.add_sample(fv[1]), daemon=True).start()
                self.system("Learned from your last voice try, so voice unlock should work better next time.")
            return
        self.pin_fails += 1
        if self.pin_fails >= 5:
            self.pin_fails = 0
            self.pin_wait_until = now + 30
            self.pin_msg.configure(text="Wrong PIN 5 times. Wait 30 seconds.")
        else:
            self.pin_msg.configure(text="Wrong PIN. Try again.", fg=C["warn"])

    def set_autolock(self, n):
        sec.set_lock_minutes(n)
        self.system("I'll only lock when I start." if n == 0 else
                    f"I'll lock myself after {n if n < 60 else n // 60} {'minutes' if n < 60 else ('hour' if n == 60 else 'hours')} without use.")

    def voice_unlock(self, audio=None, then_text=None):
        """Unlock by voice: record (or use the given audio) and compare with the saved voiceprint."""
        if not self.locked or not sec.voice_unlock_ready():
            return
        if audio is None:
            self.pin_msg.configure(text="Listening… say: Hey Vega, it's Hemanth.", fg=C["muted"])
            self.listening = True
            self.wake.paused.set()

        def work():
            nonlocal audio
            try:
                if audio is None:
                    audio = self.ears.listen_once(wait_seconds=6, silence=1.2)
                score = self.voice.score(audio) if audio is not None else None
                err = None
            except Exception as e:
                score, err = None, str(e)
            self.ui.put(lambda: done(score, err))

        def done(score, err):
            self.listening = False
            self.wake.paused.clear()
            if not self.locked:
                return
            if err:
                self.pin_msg.configure(text=f"Voice check didn't work ({err}). Use your PIN.", fg=C["warn"])
            elif score is None:
                self.pin_msg.configure(text="I didn't hear anything. Try again, or use your PIN.", fg=C["warn"])
            elif self.note_score(score) >= sec.unlock_threshold():
                self.unlock()
                self.system(f"Unlocked by your voice (match {score:.2f}).")
                if then_text and not re.search(r"\b(unlock|it'?s me|it is me|it'?s hemanth)\b", then_text.lower()):
                    self.send(then_text, spoken=True)
                else:
                    self.mouth.say("Welcome back, Hemanth.")
            else:
                self.failed_voice = (time.time(), audio)
                self.pin_msg.configure(text=f"That didn't match your voice closely enough ({score:.2f}, needs "
                                            f"{sec.unlock_threshold():.2f}). Use your PIN, and I'll learn from this try.",
                                       fg=C["warn"])

        threading.Thread(target=work, daemon=True).start()

    def unlock(self):
        self.pin_fails = 0
        self.locked = False
        if self.lock_frame:
            self.lock_frame.destroy()
        self.lock_frame = None
        self.last_activity = time.time()
        self.set_status("Ready")
        self.entry.focus_set()
        if self.pending_briefing:
            self.pending_briefing = False
            self.auto_briefing()

    def check_idle(self):
        try:
            if sec.has_pin() and sec.lock_minutes() > 0 and not self.locked \
                    and time.time() - self.last_activity > sec.lock_minutes() * 60 and not self.busy:
                self.lock()
        finally:
            self.root.after(30000, self.check_idle)

    def set_pin(self):
        if sec.has_pin():
            old = simpledialog.askstring("Change PIN", "Enter your current PIN:", show="•", parent=self.root)
            if old is None:
                return
            if not sec.check_pin(old):
                messagebox.showwarning("Wrong PIN", "That's not your current PIN.", parent=self.root)
                return
        pin = simpledialog.askstring("Set PIN", "Choose a PIN (4 to 12 digits or letters):", show="•", parent=self.root)
        if not pin:
            return
        if not re.fullmatch(r"[A-Za-z0-9]{4,12}", pin):
            messagebox.showwarning("PIN not saved", "Use 4 to 12 letters or digits, no spaces.", parent=self.root)
            return
        again = simpledialog.askstring("Set PIN", "Type the same PIN again:", show="•", parent=self.root)
        if again != pin:
            messagebox.showwarning("PIN not saved", "The two PINs were different. Try again.", parent=self.root)
            return
        sec.set_pin(pin)
        mins = sec.lock_minutes()
        self.system("PIN saved. I'll ask for it when I start" +
                    (f", and lock myself after {mins} minutes without use (change it in Menu → Auto-lock)." if mins else ".") +
                    (" You can also unlock me with your voice." if sec.voice_unlock_ready() else
                     " Set up your voice (Menu → Set up my voice) to unlock me by voice too.") +
                    "\nMenu → Lock Vega now locks me straight away.\n"
                    "If you ever forget it: quit me and delete security.json in the mybot folder.")

    def remove_pin(self):
        if not sec.has_pin():
            self.system("There's no PIN set.")
            return
        old = simpledialog.askstring("Remove PIN", "Enter your current PIN:", show="•", parent=self.root)
        if old is None:
            return
        if not sec.check_pin(old):
            messagebox.showwarning("Wrong PIN", "That's not your current PIN.", parent=self.root)
            return
        sec.remove_pin()
        self.system("PIN removed. Anyone using this laptop can use me now.")

    # ---------------- voice ID
    def install_packages(self, packages, message, then):
        self.system(message, "warn")

        def work():
            try:
                r = subprocess.run([pip_python(), "-m", "pip", "install", *packages], capture_output=True, text=True,
                                   timeout=1800, creationflags=NO_WINDOW)
                ok, detail = r.returncode == 0, (r.stdout + r.stderr).strip().splitlines()[-3:]
            except Exception as e:
                ok, detail = False, [str(e)]

            def done():
                if ok:
                    import importlib
                    importlib.invalidate_caches()
                    then()
                else:
                    self.system("Install failed:\n" + "\n".join(detail) +
                                f"\nIn PowerShell run:  \"{pip_python()}\" -m pip install " + " ".join(packages), "warn")
            self.ui.put(done)

        threading.Thread(target=work, daemon=True).start()

    def setup_voice(self):
        if self.busy or self.listening or self.locked:
            return
        missing = sec.voice_packages_missing()
        if missing:
            if messagebox.askyesno("Set up my voice",
                                   "Voice recognition needs extra parts (about 400 MB, one time). Install them now?",
                                   parent=self.root):
                self.install_packages(missing, "Installing voice recognition parts. This takes a few minutes. Keep me open.",
                                      self.setup_voice)
            return
        if not messagebox.askokcancel("Set up my voice",
                                      "I'll record you 5 times. Each time, wait for the beep, read the sentence I show, "
                                      "then stop talking.\n\nUse a quiet room and your normal voice.", parent=self.root):
            return
        sentences = ["Hey Vega, it's Hemanth.",
                     "Hey Vega, what's my task for today, and do I have any reminders?",
                     "Hey Vega, it's me, Hemanth. Unlock.",
                     "Remind me at seven in the evening to call my family and study Linux.",
                     "Open YouTube, play some music, and tell me the weather in Chennai."]
        self.listening = True
        self.wake.paused.set()
        self.mouth.stop()

        def work():
            clips = []
            try:
                self.ears.model(self.ears.model_name)
                for i, line in enumerate(sentences, 1):
                    self.ui.put(lambda i=i, line=line: (self.system(f"Recording {i} of {len(sentences)}. After the beep, say:\n“{line}”"),
                                                        self.set_status(f"Recording {i} of {len(sentences)}…", "you")))
                    time.sleep(1.2)
                    beep("wake")
                    clips.append(self.ears.listen_once(wait_seconds=8, silence=1.2))
                self.ui.put(lambda: (self.system("Learning your voice. The first time, I download a small model (about 80 MB)."),
                                     self.set_status("Learning your voice…", "accent")))
                consistency = self.voice.enroll(clips)
                sec.set_voice_only(True)
                ok, msg = True, consistency
            except Exception as e:
                ok, msg = False, str(e)

            def done():
                self.listening = False
                self.wake.paused.clear()
                self.set_status("Ready")
                if ok:
                    self.voice_only_var.set(True)
                    self.system("Your voice is saved. From now on I only obey spoken commands in your voice. "
                                "Typing always works.\nIf I ever wrongly ignore you, run Set up my voice again, "
                                f"I set my checks to fit your voice: commands need {sec.voice_threshold():.2f}, "
                                f"unlocking needs {sec.unlock_threshold():.2f}. "
                                "You can change these yourself in Menu → Voice strictness.")
                else:
                    self.system(f"Voice setup didn't work: {msg}\nTry again in a quieter place.", "warn")
            self.ui.put(done)

        threading.Thread(target=work, daemon=True).start()

    def teach_wake(self):
        """Record 'Hey Vega' 5 times and remember how Whisper hears it in Hemanth's accent."""
        if self.busy or self.listening or self.locked:
            return
        if not messagebox.askokcancel("Teach me your “Hey Vega”",
                                      "I'll listen 5 times. After each beep, say just “Hey Vega” the way you normally do, "
                                      "then stop.", parent=self.root):
            return
        self.listening = True
        self.wake.paused.set()
        self.mouth.stop()

        def work():
            heard, err = [], None
            try:
                self.ears.model(self.ears.wake_model_name)
                for i in range(1, 6):
                    self.ui.put(lambda i=i: self.set_status(f"Say “Hey Vega” ({i} of 5)…", "you"))
                    time.sleep(0.9)
                    beep("wake")
                    audio = self.ears.listen_once(wait_seconds=6, silence=0.9, max_seconds=5)
                    if audio is None:
                        continue
                    h = self.ears.transcribe(audio, fast=True)
                    heard.append(h)
                    self.ui.put(lambda h=h, i=i: self.system(f"{i}: I heard “{h or '…'}”"))
            except Exception as e:
                err = str(e)

            def done():
                self.listening = False
                self.wake.paused.clear()
                self.set_status("Ready")
                if err:
                    self.system(f"That didn't work: {err}", "warn")
                    return
                new = vega_voice.learn_wake_words(heard)
                vega_voice.LEARNED.update(new)
                saved = sorted(set(self.vega.cfg.get("wake_variants", [])) | vega_voice.LEARNED)[:30]
                self.vega.cfg["wake_variants"] = saved
                save_config_value("wake_variants", saved)
                caught = sum(1 for h in heard if vega_voice.find_wake(h) is not None)
                self.system(f"Learned how I hear you: {', '.join(sorted(new)) or 'nothing new'}. "
                            f"Now I catch your “Hey Vega” in {caught} of {len(heard)} tries."
                            + ("" if self.wake_var.get() else " Tick “Listen for Hey Vega” to use it."))
            self.ui.put(done)

        threading.Thread(target=work, daemon=True).start()

    def toggle_telugu(self):
        on = bool(self.telugu_var.get())
        self.ears.telugu = on
        self.vega.cfg["understand_telugu"] = on
        save_config_value("understand_telugu", on)
        if on:
            self.system("Telugu on. Speak in Telugu, English, or a mix. I'll understand and show your words in English, "
                        "then answer in English. Keep saying “Hey Vega” in English to wake me.\n"
                        "The first time you press Mic, I download the Telugu-capable model (about 500 MB).\n"
                        "Tip: for better Telugu (but slower), set \"telugu_model\": \"medium\" in Menu → Edit settings.")
        else:
            self.system("Telugu off. Back to English-only listening, which is a bit more accurate for English.")

    def toggle_speak_telugu(self):
        on = bool(self.speak_te_var.get())
        if on:
            import importlib.util
            missing = [p for p, m in (("edge-tts", "edge_tts"), ("deep-translator", "deep_translator"))
                       if importlib.util.find_spec(m) is None]
            if missing:
                self.speak_te_var.set(False)
                self.install_packages(missing, "Installing the Telugu voice parts (small, about 1 minute)…",
                                      lambda: (self.speak_te_var.set(True), self.toggle_speak_telugu()))
                return
        self.mouth.telugu = on
        self.vega.cfg["speak_telugu"] = on
        save_config_value("speak_telugu", on)
        if on:
            self.system("Telugu voice on. I'll show answers in English on screen and speak them in Telugu.\n"
                        "This uses the internet: the spoken part is translated by Google Translate and read by "
                        "Microsoft's Telugu voice, so those services see it. If there's no internet, I speak English.\n"
                        "For a male voice, set \"telugu_voice\": \"te-IN-MohanNeural\" in Menu → Edit settings.")
            self.mouth.say("Hello Hemanth. From now on, I will speak to you in Telugu.")
        else:
            self.system("Telugu voice off. I'll speak English again.")

    # ---------------- brain (AI model)
    def fill_brain_menu(self):
        m = self.brain_menu
        m.delete(0, "end")
        main = self.vega.cfg.get("model") or "vega"
        chosen = (self.vega.cfg.get("chat_model") or "").strip() or main
        self.brain_var = tk.StringVar(value=chosen)
        m.add_command(label="For chatting, use:", state="disabled")
        names = self.vega.installed_models()
        if not names:
            m.add_command(label="  (Ollama isn't running)", state="disabled")
        for name in names:
            if name.lower().startswith(("nomic", "mxbai", "all-minilm")) or "embed" in name.lower():
                continue  # not chat models
            label = name + ("   (Vega, fast)" if self.vega._same(name, main) else "")
            m.add_radiobutton(label=label, value=name if not self.vega._same(name, main) else main,
                              variable=self.brain_var, command=lambda: self.set_brain(self.brain_var.get()))
        m.add_separator()
        self.auto_code_var = tk.BooleanVar(value=bool(self.vega.cfg.get("auto_code_model", True)))
        code = self.vega.cfg.get("code_model") or "qwen2.5-coder:3b"
        m.add_checkbutton(label=f"Use {code} for code questions", variable=self.auto_code_var,
                          command=self.toggle_auto_code)
        m.add_command(label="How to get a smarter brain…", command=self.brain_help)

    def set_brain(self, name):
        main = self.vega.cfg.get("model") or "vega"
        value = "" if self.vega._same(name, main) else name
        self.vega.cfg["chat_model"] = value
        save_config_value("chat_model", value)
        if value:
            self.system(f"Okay. {name} now answers when we chat. Commands still use my fast brain.\n"
                        "The first answer may take a little longer while it loads.")
            threading.Thread(target=self._warm, args=(name,), daemon=True).start()
        else:
            self.system("Okay. I'm back to my normal fast brain for chatting.")

    @staticmethod
    def _warm(name):
        try:
            import ollama
            ollama.generate(model=name, prompt="", keep_alive="15m")
        except Exception:
            pass

    def toggle_auto_code(self):
        on = bool(self.auto_code_var.get())
        self.vega.cfg["auto_code_model"] = on
        save_config_value("auto_code_model", on)
        code = self.vega.cfg.get("code_model") or "qwen2.5-coder:3b"
        self.system(f"Code questions will go to {code}." if on else "Code questions will use my normal brain.")

    def brain_help(self):
        self.system("To give me a smarter brain for chatting:\n"
                    "1. Open PowerShell and run:  ollama pull qwen2.5:7b\n"
                    "   (about 4.7 GB; wait until it says success)\n"
                    "2. Menu → Brain (AI model) → pick qwen2.5:7b\n"
                    "It's smarter but a bit slower. To go back, pick vega:latest.\n"
                    "Commands like 'open YouTube' always use my fast brain.")

    def note_score(self, score):
        self.recent_scores = (self.recent_scores + [round(float(score), 2)])[-8:]
        return score

    def voice_strictness(self):
        """Two sliders (0.20 to 0.45): how closely a voice must match Hemanth's."""
        if not self.voice.has_voiceprint():
            messagebox.showinfo("Voice strictness", "First set up your voice: Menu → Set up my voice.", parent=self.root)
            return
        if sec.has_pin():  # so nobody else can make the voice check easier
            pin = simpledialog.askstring("Voice strictness", "Enter your PIN:", show="•", parent=self.root)
            if pin is None:
                return
            if not sec.check_pin(pin):
                messagebox.showwarning("Wrong PIN", "That's not your PIN.", parent=self.root)
                return
        win = tk.Toplevel(self.root)
        win.title("Voice strictness")
        win.configure(bg=C["bg"], padx=18, pady=14)
        win.resizable(False, False)
        win.transient(self.root)
        tk.Label(win, text="How closely must a voice match yours?", bg=C["bg"], fg=C["ink"], font=F_BOLD).pack(anchor="w")
        tk.Label(win, text="Lower number = easier (fewer wrong “ignored” messages, but other people may get through).\n"
                           "Higher number = stricter (safer, but may ignore you in a noisy room).",
                 bg=C["bg"], fg=C["muted"], font=F_SMALL, justify="left").pack(anchor="w", pady=(2, 10))
        cmd_var = tk.DoubleVar(value=sec.voice_threshold())
        unl_var = tk.DoubleVar(value=sec.unlock_threshold())
        for label, var in (("Voice commands need:", cmd_var), ("Voice unlock needs:", unl_var)):
            tk.Label(win, text=label, bg=C["bg"], fg=C["ink"], font=F).pack(anchor="w")
            tk.Scale(win, from_=sec.MIN_LEVEL, to=sec.MAX_LEVEL, resolution=0.01, orient="horizontal", length=360,
                     variable=var, bg=C["bg"], fg=C["ink"], troughcolor=C["entry"], highlightthickness=0,
                     activebackground=C["accent"], font=F).pack(anchor="w", pady=(0, 8))
        seen = ", ".join(f"{x:.2f}" for x in self.recent_scores) or "none yet (speak to me a few times first)"
        tk.Label(win, text=f"Your last voice matches: {seen}\nTip: set commands a little below your usual match.",
                 bg=C["bg"], fg=C["muted"], font=F_SMALL, justify="left").pack(anchor="w", pady=(0, 10))
        row = tk.Frame(win, bg=C["bg"])
        row.pack(anchor="e")

        def save():
            c, u = cmd_var.get(), unl_var.get()
            if u < c:
                u = c  # unlocking should never be easier than a normal command
            sec.set_thresholds(c, u)
            win.destroy()
            self.system(f"Saved. Voice commands need {sec.voice_threshold():.2f}, "
                        f"voice unlock needs {sec.unlock_threshold():.2f}.")

        tk.Button(row, text="Cancel", command=win.destroy, bg=C["btn"], fg=C["ink"], relief="flat",
                  activebackground=C["btn_hi"], padx=12).pack(side="left", padx=(0, 8))
        tk.Button(row, text="Save", command=save, bg=C["accent"], fg=C["bg"], relief="flat",
                  activebackground=C["btn_hi"], padx=16).pack(side="left")
        win.grab_set()

    def toggle_voice_only(self):
        on = bool(self.voice_only_var.get())
        if on and not self.voice.has_voiceprint():
            self.voice_only_var.set(False)
            self.setup_voice()
            return
        sec.set_voice_only(on)
        self.system("I'll only obey spoken commands in your voice." if on else "I'll obey any voice again.")

    # ---------------- phone
    def start_phone(self):
        if self.phone:
            self.phone.running = False  # the old link stops after its current check
            self.phone = None
        if not str(self.vega.cfg.get("telegram_token") or "").strip():
            return
        from vega_telegram import TelegramBridge
        self.phone = TelegramBridge(self.vega, self.ears, lambda *ev: self.ui.put(lambda ev=ev: self.phone_event(*ev)))
        self.phone.start()

    def phone_event(self, kind, *data):
        if kind == "status":
            self.system(data[0])
        elif kind == "phone":
            text_in, text_out = data
            self.add_message("phone", text_in)
            self.add_message("vega", text_out)
        elif kind == "pair_request":
            chat_id, name = data
            self.pending_pair = (chat_id, name)
            self.system(f"{name} messaged your Vega bot on Telegram. If that's you, type  allow phone  and press Enter.", "warn")
            self.show()
            ok = messagebox.askyesno("Connect this phone?",
                                     f"{name} just messaged your Vega bot on Telegram.\n\n"
                                     f"Allow this chat to control Vega?\nOnly say Yes if it's YOU.", parent=self.root)
            if ok:
                self.allow_phone()

    def allow_phone(self):
        pending = getattr(self, "pending_pair", None)
        if not pending or not self.phone:
            self.system("No phone is waiting to connect. Send 'hi' to your bot from your phone first.")
            return
        chat_id, _ = pending
        self.pending_pair = None
        save_config_value("telegram_chat_id", str(chat_id))
        self.vega.cfg["telegram_chat_id"] = str(chat_id)
        self.phone.pair(chat_id)
        self.system("Phone connected. You can now message Vega on Telegram while this laptop is on.")

    def connect_phone(self):
        token = simpledialog.askstring(
            "Connect phone (Telegram)",
            "1. In Telegram, open @BotFather and send /newbot\n"
            "2. Give it a name and a username ending in 'bot'\n"
            "3. Copy the token it gives you and paste it here:",
            parent=self.root)
        if not token:
            return
        token = token.strip()
        if not re.match(r"^\d+:[A-Za-z0-9_-]{20,}$", token):
            messagebox.showwarning("That doesn't look right", "A bot token looks like 123456789:AAH... Copy it again from BotFather.")
            return
        save_config_value("telegram_token", token)
        save_config_value("telegram_chat_id", "")
        self.vega.cfg["telegram_token"] = token
        self.vega.cfg["telegram_chat_id"] = ""
        self.start_phone()
        self.system("Now open your new bot in Telegram and send it 'hi'. A box will pop up here: click Yes.")

    # ---------------- settings
    def toggle_voice(self):
        on = bool(self.voice_var.get())
        save_config_value("voice_on", on)
        if not on:
            self.mouth.stop()

    def toggle_wake(self):
        on = bool(self.wake_var.get())
        save_config_value("wake_word_on", on)
        self.wake.set_enabled(on)
        if on:
            self.system("Listening for “Hey Vega”. Say it, wait for the beep, then speak. "
                        "(The first time, it downloads a small speech model. It uses a little CPU while on.)")
        else:
            self.system("Stopped listening for “Hey Vega”.")

    def toggle_startup(self):
        lnk = startup_shortcut_path()
        try:
            if self.startup_var.get():
                make_shortcut(lnk)
                self.system("Done. Vega will start by herself when you turn on your laptop.")
            else:
                if os.path.exists(lnk):
                    os.remove(lnk)
                self.system("Vega won't start with Windows any more.")
        except Exception as e:
            self.startup_var.set(os.path.exists(lnk))
            self.system(f"Couldn't change that: {e}", "warn")

    def desktop_shortcut(self):
        try:
            make_shortcut(os.path.join(desktop_folder(), "Vega.lnk"))
            self.system("Added a Vega shortcut to your desktop. Double-click it to open me.")
        except Exception as e:
            self.system(f"Couldn't make the shortcut: {e}", "warn")

    def edit_settings(self):
        path = here("config.json")
        if IS_WINDOWS:
            subprocess.Popen(["notepad.exe", path])
        self.system("Change settings in Notepad, save, then quit and reopen Vega.")

    def clear_chat(self):
        self.text.delete("1.0", "end")
        try:
            open(here(LOG_FILE), "w", encoding="utf-8").close()
        except OSError:
            pass
        self.vega.history = []
        self.vega._save_history()
        self.system("Chat cleared. (Your notebook, reminders, to-dos and diary are kept.)")

    # ---------------- start, close
    def greet(self):
        h = datetime.now().hour
        part = "morning" if h < 12 else ("afternoon" if h < 17 else "evening")
        msg = f"Good {part}, Hemanth. Vega here."
        plan = self.vega.load_plan()
        if plan:
            idx = self.vega.today_index(plan)
            d = self.vega.plan_day(plan, idx)
            if d:
                done = self.vega.is_done(idx)
                streak, _ = self.vega.streaks(idx)
                msg += f" Today's study task is {d['title']}" + (", and it's already done. Nice." if done else ".")
                if streak >= 2:
                    msg += f" You're on a {streak}-day streak."
        self.add_message("vega", msg + " What do you need?", save=False)
        if self.voice_var.get():
            self.mouth.say(msg)

    def repair_if_needed(self):
        missing = missing_packages()
        if not missing:
            return
        self.system("Some parts I need aren't installed for the Python I'm running on: " + ", ".join(missing) +
                    ". Installing them now. This takes 1 to 3 minutes. Keep me open.", "warn")

        def work():
            try:
                r = subprocess.run([pip_python(), "-m", "pip", "install", *missing], capture_output=True, text=True,
                                   timeout=900, creationflags=NO_WINDOW)
                ok = r.returncode == 0
                detail = (r.stdout + r.stderr).strip().splitlines()[-3:]
            except Exception as e:
                ok, detail = False, [str(e)]

            def done():
                if ok:
                    import importlib
                    importlib.invalidate_caches()
                    self.system("Done. Everything is installed now.")
                    self.start_phone()
                else:
                    self.system("I couldn't install them myself:\n" + "\n".join(detail) +
                                f"\nIn PowerShell run:  \"{pip_python()}\" -m pip install " + " ".join(missing), "warn")
            self.ui.put(done)

        threading.Thread(target=work, daemon=True).start()

    def check_ollama(self):
        try:
            import ollama
            names = [m.model for m in ollama.list().models]
            model = self.vega.cfg["model"]
            if not any(n == model or n.startswith(model + ":") for n in names):
                self.ui.put(lambda: self.system(f"I can't find the model '{model}'. In PowerShell run: "
                                                f"ollama create {model} -f Modelfile-full", "warn"))
                return
            ollama.generate(model=model, prompt="", keep_alive="15m")  # load me into the GPU now, so the first answer is fast
        except Exception:
            self.ui.put(lambda: self.system("I can't reach Ollama. Open the Ollama app from the Start menu. "
                                            "Commands still work; chatting needs Ollama.", "warn"))

    def accept_other_instances(self, server):
        while True:
            try:
                conn, _ = server.accept()
                conn.close()
                self.ui.put(self.show)
            except OSError:
                return

    def show(self):
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()

    def on_close(self):
        self.root.iconify()
        if not self.told_about_close:
            self.told_about_close = True
            self.system("I'm still running in the taskbar so your reminders work. To close me fully: Menu → Quit Vega.")

    def quit(self):
        self.mouth.stop()
        self.root.destroy()
        os._exit(0)

    def poll(self):
        try:
            while True:
                fn = self.ui.get_nowait()
                try:
                    fn()
                except Exception as e:
                    print("UI error:", e)
        except queue.Empty:
            pass
        self.root.after(50, self.poll)


def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        server.bind(("127.0.0.1", PORT))
        server.listen(2)
    except OSError:
        try:  # Vega is already running: bring that window to the front instead
            socket.create_connection(("127.0.0.1", PORT), timeout=2).close()
        except OSError:
            pass
        return
    if IS_WINDOWS:
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)  # sharp text on laptop screens
        except Exception:
            pass
    root = tk.Tk()

    def report(*exc):
        import traceback
        with open(here("vega_error.log"), "a", encoding="utf-8") as f:
            f.write(f"\n--- {datetime.now()} ---\n" + "".join(traceback.format_exception(*exc)))

    root.report_callback_exception = report
    try:
        App(root, server)
    except Exception:
        report(*sys.exc_info())
        messagebox.showerror("Vega couldn't start",
                             "Something went wrong while starting. The details are in vega_error.log "
                             "in your mybot folder. Send a screenshot of that file.")
        return
    root.mainloop()


if __name__ == "__main__":
    main()
