"""
Vega's ears and mouth.

Mouth: speaks with the Windows voice (through PowerShell, so it can be stopped).
Ears:  records from the microphone and turns speech into text with Whisper,
       all on your laptop. Stops by itself when you stop talking.
WakeListener: listens in the background for "Hey Vega".
"""

import difflib
import os
import queue
import re
import subprocess
import threading
import time

import numpy as np

IS_WINDOWS = os.name == "nt"
NO_WINDOW = 0x08000000 if IS_WINDOWS else 0
SAMPLE_RATE = 16000
BLOCK = 1600  # 0.1 second of audio


def clean_for_speech(text):
    text = re.sub(r"```.*?```", " (the code is on screen) ", text, flags=re.S)
    text = re.sub(r"https?://\S+", "", text)
    text = re.sub(r"`([^`]*)`", r"\1", text)
    text = re.sub(r"[*_#>|•]", " ", text)
    text = re.sub(r"^\s*\d+\.\s+", "", text, flags=re.M)
    text = text.replace("°C", " degrees").replace("%", " percent").replace("→", " ")
    return re.sub(r"\s+", " ", text).strip()


def shorten_for_speech(text, max_sentences=3, max_chars=350):
    """Long answers stay on screen; Vega only reads the start out loud."""
    text = clean_for_speech(text)
    parts = re.split(r"(?<=[.!?])\s+", text)
    out = " ".join(parts[:max_sentences])
    if len(out) > max_chars:
        out = out[:max_chars].rsplit(" ", 1)[0] + "."
    if len(parts) > max_sentences or len(text) > len(out) + 5:
        out += " The rest is on screen."
    return out


class Mouth:
    SCRIPT = (
        "Add-Type -AssemblyName System.Speech;"
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        "try { if ($env:VEGA_VOICE -eq 'female') { $s.SelectVoiceByHints([System.Speech.Synthesis.VoiceGender]::Female) } } catch {};"
        "$s.Rate = [int]$env:VEGA_RATE;"
        "$s.Speak($env:VEGA_SAY)"
    )

    def __init__(self, rate=1, voice="female"):
        self.rate, self.voice = rate, voice
        self.q = queue.Queue()
        self.proc = None
        # Telugu voice: translate the answer to Telugu (Google Translate) and speak it with
        # Microsoft's free neural Telugu voice. Needs internet; falls back to English if it fails.
        self.telugu = False
        self.telugu_voice = "te-IN-ShrutiNeural"
        self.on_error = None
        self._stop = threading.Event()
        self.speaking = threading.Event()
        self.last_spoke = 0.0
        threading.Thread(target=self._run, daemon=True).start()

    def say(self, text):
        text = clean_for_speech(text or "")
        if text:
            self.q.put(text)

    def stop(self):
        try:
            while True:
                self.q.get_nowait()
        except queue.Empty:
            pass
        self._stop.set()
        p = self.proc
        if p and p.poll() is None:
            p.kill()
        if IS_WINDOWS:
            try:
                import winsound
                winsound.PlaySound(None, winsound.SND_PURGE)
            except Exception:
                pass

    @staticmethod
    def to_telugu(text):
        from deep_translator import GoogleTranslator
        return GoogleTranslator(source="auto", target="te").translate(text[:4500])

    def _speak_telugu(self, text):
        import asyncio
        import tempfile
        import wave
        import edge_tts
        te = self.to_telugu(text)
        folder = tempfile.gettempdir()
        mp3, wav = os.path.join(folder, "vega_say.mp3"), os.path.join(folder, "vega_say.wav")
        asyncio.run(edge_tts.Communicate(te, self.telugu_voice).save(mp3))
        # turn the mp3 into a wav that Windows can play without extra programs
        import av
        pcm = bytearray()
        with av.open(mp3) as container:
            resampler = av.AudioResampler(format="s16", layout="mono", rate=24000)
            for frame in container.decode(audio=0):
                for f in resampler.resample(frame):
                    pcm += f.to_ndarray().tobytes()
            for f in resampler.resample(None):
                pcm += f.to_ndarray().tobytes()
        with wave.open(wav, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(24000)
            w.writeframes(bytes(pcm))
        if self._stop.is_set():
            return
        import winsound
        winsound.PlaySound(wav, winsound.SND_FILENAME | winsound.SND_ASYNC)
        end = time.time() + len(pcm) / 2 / 24000 + 0.2
        while time.time() < end and not self._stop.is_set():
            time.sleep(0.1)

    def busy(self):
        """True while speaking, and for a moment after (so the mic doesn't hear Vega)."""
        return self.speaking.is_set() or (time.time() - self.last_spoke) < 0.8

    def _run(self):
        while True:
            text = self.q.get()
            self.speaking.set()
            self._stop.clear()
            try:
                if IS_WINDOWS and self.telugu:
                    try:
                        self._speak_telugu(text)
                        continue
                    except Exception as e:  # no internet, missing part... speak English instead
                        if self.on_error:
                            self.on_error(f"Couldn't speak Telugu ({e}), so I spoke English.")
                if IS_WINDOWS:
                    env = dict(os.environ, VEGA_SAY=text[:3000], VEGA_RATE=str(int(self.rate)), VEGA_VOICE=self.voice)
                    self.proc = subprocess.Popen(
                        ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", self.SCRIPT],
                        env=env, creationflags=NO_WINDOW)
                    self.proc.wait()
            except Exception:
                pass
            finally:
                self.last_spoke = time.time()
                if self.q.empty():
                    self.speaking.clear()


def beep(kind="wake"):
    if IS_WINDOWS:
        try:
            import winsound
            if kind == "wake":
                winsound.Beep(880, 120)
            else:
                winsound.Beep(660, 150)
                winsound.Beep(880, 150)
                winsound.Beep(990, 200)
        except Exception:
            pass


class Ears:
    def __init__(self, model_name="small.en", wake_model_name="base.en"):
        self.model_name, self.wake_model_name = model_name, wake_model_name
        self._models = {}
        self._lock = threading.Lock()
        self.hint = "Hey Vega."  # names and words to expect; the app fills this in
        # Telugu mode: a multilingual model hears Telugu, English or a mix, and writes it down in English
        self.telugu = False
        self.telugu_model_name = "small"

    def model(self, name):
        with self._lock:
            if name not in self._models:
                from faster_whisper import WhisperModel
                self._models[name] = WhisperModel(name, device="cpu", compute_type="int8")
            return self._models[name]

    def main_model_name(self):
        return self.telugu_model_name if self.telugu else self.model_name

    def _words(self, source, fast=False, prompt=None):
        if fast:  # wake word: always the small English model
            segments, _ = self.model(self.wake_model_name).transcribe(
                source, language="en", vad_filter=False, beam_size=2,
                initial_prompt=prompt or "Hey Vega. Hi Vega. Okay Vega.")
        elif self.telugu:  # Telugu / Tenglish / English speech -> English text
            segments, _ = self.model(self.telugu_model_name).transcribe(
                source, task="translate", vad_filter=True, beam_size=5, initial_prompt=prompt or self.hint)
        else:
            segments, _ = self.model(self.model_name).transcribe(
                source, language="en", vad_filter=True, beam_size=5, initial_prompt=prompt or self.hint)
        return " ".join(s.text.strip() for s in segments).strip()

    def transcribe(self, audio, fast=False, prompt=None):
        return self._words(audio, fast, prompt)

    def transcribe_file(self, path):
        return self._words(path)

    def listen_once(self, stop_event=None, max_seconds=20, silence=1.3, wait_seconds=7):
        """Record until you stop talking (or press the mic again). Returns audio or None."""
        import sounddevice as sd
        blocks = queue.Queue()

        def cb(indata, frames, t, status):
            blocks.put(indata[:, 0].copy())

        audio, started, quiet, noise = [], False, 0.0, None
        begin = time.time()
        with sd.InputStream(samplerate=SAMPLE_RATE, channels=1, dtype="float32", blocksize=BLOCK, callback=cb):
            while True:
                if stop_event is not None and stop_event.is_set():
                    break
                try:
                    b = blocks.get(timeout=0.5)
                except queue.Empty:
                    continue
                rms = float(np.sqrt(np.mean(b ** 2)))
                if noise is None:
                    noise = rms
                threshold = max(noise * 3.0, 0.006)
                if not started:
                    noise = 0.9 * noise + 0.1 * rms if rms < threshold else noise
                    audio = (audio + [b])[-3:]  # keep a little audio from just before you start
                    if rms > threshold and time.time() - begin > 0.2:
                        started = True
                    elif time.time() - begin > wait_seconds:
                        return None
                    continue
                audio.append(b)
                quiet = quiet + 0.1 if rms < threshold else 0.0
                if quiet >= silence or len(audio) * 0.1 >= max_seconds:
                    break
        if not started or len(audio) < 5:
            return None
        return np.concatenate(audio)


WAKE_WORDS = {"vega", "wega", "vegas", "veega", "vaiga", "vayga", "vaga", "weiga", "vegah", "veiga", "baega", "bega",
              "vegha", "waiga", "weega", "wiga", "viga", "vayega", "vaigha", "bhega", "beiga", "vegaa", "wegah"}
GREETINGS = {"hey", "hi", "hay", "he", "hei", "hai", "ok", "okay", "o", "a", "ay", "hello", "hye", "heyy"}
LEARNED = set()  # how Whisper hears YOUR "Vega" (from Menu -> Teach me your "Hey Vega")


def _sim(a, b):
    return difflib.SequenceMatcher(None, a, b).ratio()


def find_wake(text):
    """If the text starts with the wake word, return what came after it ('' if nothing). Else None.
    Flexible on purpose: Whisper spells 'Vega' many ways for Indian accents ('wega', 'vaiga', 'bega'...)."""
    words = re.findall(r"[a-z']+", text.lower())
    known = WAKE_WORDS | LEARNED
    for i, w in enumerate(words[:4]):
        if w in known or _sim(w, "vega") >= 0.75:
            return " ".join(words[i + 1:])
        after_greeting = i > 0 and words[i - 1] in GREETINGS
        if after_greeting and (max((_sim(w, k) for k in known), default=0) >= 0.6 or
                               (len(w) <= 6 and w[:1] in "vwb" and _sim(w, "vega") >= 0.5)):
            return " ".join(words[i + 1:])
        # "hey vega" heard as one word, e.g. "heyvega" / "haivega"
        if len(w) > 5 and w[:3] in ("hey", "hai", "hay") and _sim(w[3:], "vega") >= 0.6:
            return " ".join(words[i + 1:])
    return None


def learn_wake_words(heard_list):
    """From recordings of 'Hey Vega', pick out the word Whisper heard for 'Vega'. Returns the new words."""
    new = set()
    for heard in heard_list:
        words = re.findall(r"[a-z']+", (heard or "").lower())
        for i, w in enumerate(words[:4]):
            if w in GREETINGS:
                continue
            if len(w) >= 2 and w not in {"the", "and", "you", "i", "is", "it", "to", "me"}:
                new.add(w)
                break
    return new


class WakeListener(threading.Thread):
    """
    Listens all the time for "Hey Vega". Uses the small Whisper model on short bits of sound.
    on_wake()          -> called when she hears her name (show "Yes?")
    on_command(text)   -> called with what you said after her name
    is_busy()          -> True while Vega is speaking or thinking (then she doesn't listen)
    """

    def __init__(self, ears, on_wake, on_command, is_busy, on_error=None):
        super().__init__(daemon=True)
        self.ears, self.on_wake, self.on_command, self.is_busy, self.on_error = ears, on_wake, on_command, is_busy, on_error
        self.enabled = threading.Event()
        self.paused = threading.Event()

    def set_enabled(self, on):
        (self.enabled.set if on else self.enabled.clear)()

    def run(self):
        import sounddevice as sd
        try:
            self.ears.model(self.ears.wake_model_name)
        except Exception as e:
            if self.on_error:
                self.on_error(f"Couldn't load the wake-word model: {e}")
            return
        while True:
            if not self.enabled.is_set() or self.paused.is_set():
                time.sleep(0.3)
                continue
            blocks = queue.Queue()

            def cb(indata, frames, t, status):
                blocks.put(indata[:, 0].copy())

            try:
                with sd.InputStream(samplerate=SAMPLE_RATE, channels=1, dtype="float32", blocksize=BLOCK, callback=cb):
                    self._loop(blocks)
            except Exception as e:
                if self.on_error:
                    self.on_error(f"Microphone problem: {e}")
                time.sleep(3)

    def _loop(self, blocks):
        noise, seg, quiet, pre = None, [], 0.0, []
        waiting_for_command_until = 0.0
        while self.enabled.is_set() and not self.paused.is_set():
            try:
                b = blocks.get(timeout=0.5)
            except queue.Empty:
                continue
            if self.is_busy():
                seg, quiet, pre = [], 0.0, []
                continue
            rms = float(np.sqrt(np.mean(b ** 2)))
            noise = rms if noise is None else noise
            threshold = max(noise * 3.0, 0.008)
            if not seg:
                if rms > threshold:
                    seg = pre[-2:] + [b]
                    quiet = 0.0
                else:
                    noise = 0.95 * noise + 0.05 * rms
                    pre = (pre + [b])[-3:]
                    if waiting_for_command_until and time.time() > waiting_for_command_until:
                        waiting_for_command_until = 0.0
                continue
            seg.append(b)
            quiet = quiet + 0.1 if rms < threshold else 0.0
            long_enough = len(seg) * 0.1 >= (15 if waiting_for_command_until else 6)
            if quiet < (1.2 if waiting_for_command_until else 0.6) and not long_enough:
                continue
            audio = np.concatenate(seg)
            seg, quiet, pre = [], 0.0, []
            if len(audio) < SAMPLE_RATE * 0.3:
                continue
            if waiting_for_command_until:
                waiting_for_command_until = 0.0
                text = self.ears.transcribe(audio)
                if text:
                    self.on_command(text, audio)
                continue
            heard = self.ears.transcribe(audio, fast=True)
            rest = find_wake(heard) if heard else None
            if rest is None:
                continue
            if len(rest.split()) >= 2:
                # "Hey Vega, what's the weather" - hear it again with the better model
                text = self.ears.transcribe(audio)
                cmd = find_wake(text)
                self.on_command(cmd if cmd and len(cmd.split()) >= 2 else rest, audio)
            else:
                beep("wake")
                self.on_wake()
                waiting_for_command_until = time.time() + 8
