"""Pages shown in Vega's main area from the sidebar: News, Tech news, Internships (fresh every day)."""

import threading
import tkinter as tk
from datetime import datetime

from vega_lablog import INTERN_QUERY


class ScrollFrame(tk.Frame):
    """A frame that scrolls with the mouse wheel."""

    def __init__(self, parent, bg):
        super().__init__(parent, bg=bg)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        self.bar = tk.Scrollbar(self, command=self.canvas.yview, relief="flat", bd=0)
        self.inner = tk.Frame(self.canvas, bg=bg)
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.win, width=e.width))
        self.canvas.configure(yscrollcommand=self.bar.set)
        self.bar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        for w in (self.canvas, self.inner):
            w.bind("<Enter>", lambda e: self.canvas.bind_all("<MouseWheel>", self._wheel))
            w.bind("<Leave>", lambda e: self.canvas.unbind_all("<MouseWheel>"))

    def _wheel(self, e):
        self.canvas.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1), "units")


class FeedPage:
    """A list of headlines with Open buttons, loaded in the background, with a Refresh button."""

    def __init__(self, app, parent, kind):
        self.app, self.vega, self.kind = app, app.vega, kind
        C, F = app.C, app.F
        self.C, self.F = C, F
        self.frame = tk.Frame(parent, bg=C["bg"])
        head = tk.Frame(self.frame, bg=C["bg"])
        head.pack(fill="x", padx=28, pady=(22, 4))
        titles = {"news": ("Top news", "India and the world, fresh from Google News"),
                  "tech": ("Tech news", "Technology, AI, cloud and gadgets from the last day"),
                  "internships": ("Internships", "New internship news from the last day, and live job searches")}
        t, sub = titles[kind]
        tk.Label(head, text=t, font=F["title"], bg=C["bg"], fg=C["ink"]).pack(side="left")
        app.button(head, "Refresh", self.load, font=F["small"]).pack(side="right")
        self.sub = tk.Label(self.frame, text=sub, font=F["small"], bg=C["bg"], fg=C["muted"], anchor="w")
        self.sub.pack(fill="x", padx=28, pady=(0, 10))
        self.scroll = ScrollFrame(self.frame, C["bg"])
        self.scroll.pack(fill="both", expand=True, padx=(20, 8), pady=(0, 12))
        self.load()

    def clear(self):
        for w in self.scroll.inner.winfo_children():
            w.destroy()

    def note(self, text):
        tk.Label(self.scroll.inner, text=text, font=self.F["normal"], bg=self.C["bg"], fg=self.C["muted"],
                 anchor="w", justify="left").pack(fill="x", padx=8, pady=8)

    def load(self):
        self.clear()
        self.note("Loading…")

        def work():
            items, links, err = [], [], None
            try:
                if self.kind == "news":
                    items = self.vega.fetch_news(None, 15)
                elif self.kind == "tech":
                    items = self.vega.fetch_news("technology OR AI OR cloud computing OR smartphones", 15)
                else:
                    seen = set((self.vega_state().get("seen_internships") or []))
                    items = [(h, u, h not in seen) for h, u in self.vega.fetch_news(INTERN_QUERY, 15)]
                    links = self.vega.internship_links()
                    self.vega.fresh_internship_news(15)  # remember what he has now seen
            except Exception as e:
                err = str(e)
            self.app.ui.put(lambda: self.show(items, links, err))

        threading.Thread(target=work, daemon=True).start()

    def vega_state(self):
        from vega_core import read_json
        return read_json("briefing_state.json", {}) or {}

    def show(self, items, links, err):
        if not self.frame.winfo_exists():
            return
        self.clear()
        C, F = self.C, self.F
        if err:
            self.note(f"I couldn't load this ({err}).\nCheck your internet and press Refresh.")
            return
        if links:
            box = tk.Frame(self.scroll.inner, bg=C["bg"])
            box.pack(fill="x", padx=8, pady=(0, 10))
            tk.Label(box, text="Live searches (new posts every day):", font=F["bold"], bg=C["bg"], fg=C["ink"],
                     anchor="w").pack(fill="x", pady=(0, 6))
            row = tk.Frame(box, bg=C["bg"])
            row.pack(fill="x")
            for name, url in links:
                short = name.replace(" internships", "").split(" roles")[0].replace(": ", " · ")
                short = short if len(short) <= 30 else short[:28] + "…"
                self.app.button(row, short, lambda u=url: self.open(u), font=F["small"]).pack(side="left", padx=(0, 6), pady=2)
        if not items:
            self.note("Nothing new right now. Try Refresh later.")
            return
        for it in items:
            head, url = it[0], it[1]
            new = it[2] if len(it) > 2 else False
            source = ""
            if head.endswith(")") and " (" in head:
                head, source = head[:-1].rsplit(" (", 1)
            card = tk.Frame(self.scroll.inner, bg=C["panel"], highlightbackground=C["line"], highlightthickness=1, cursor="hand2")
            card.pack(fill="x", padx=8, pady=4)
            tk.Label(card, text=("NEW  ·  " if new else "") + (source or "News"), font=F["small"], bg=C["panel"],
                     fg=C["ok"] if new else C["muted"], anchor="w").pack(fill="x", padx=12, pady=(8, 0))
            lbl = tk.Label(card, text=head, font=F["normal"], bg=C["panel"], fg=C["ink"], anchor="w", justify="left",
                           wraplength=640, cursor="hand2")
            lbl.pack(fill="x", padx=12, pady=(2, 10))
            for w in (card, lbl):
                w.bind("<Button-1>", lambda e, u=url: self.open(u))
        tk.Label(self.scroll.inner, text=f"Updated {datetime.now().strftime('%I:%M %p').lstrip('0')}  ·  click a story to open it",
                 font=F["small"], bg=C["bg"], fg=C["muted"], anchor="w").pack(fill="x", padx=8, pady=10)

    def open(self, url):
        try:
            self.vega.open_in_browser(self.vega.browser_key(""), url)
        except Exception:
            import webbrowser
            webbrowser.open(url)
