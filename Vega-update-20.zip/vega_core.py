"""
Vega's brain.

It understands commands (open apps, reminders, to-dos, weather, news, your VM,
your diary, your documents, your 24-week plan) and runs them directly with
Python. Anything that isn't a command goes to your own Ollama model ("vega").

The AI model only talks. The actions are done by this file, so a small model
like llama3.2:3b is enough.

Everything stays on your laptop. The internet is used only for weather, news
and Wikipedia (free, no account), and for Telegram if you turn it on.
"""

import difflib
import json
import os
import re
import shutil
import subprocess
import threading
import time
import urllib.parse
import webbrowser
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta

BASE = os.path.dirname(os.path.abspath(__file__))
IS_WINDOWS = os.name == "nt"
NO_WINDOW = 0x08000000 if IS_WINDOWS else 0
LAB_LOG_URL = "https://claude.ai/artifact/V4udxiajsAqpcaZeZFSYRk"
USER_AGENT = "VegaPersonalAssistant/2.0 (personal use)"


def here(*parts):
    return os.path.join(BASE, *parts)


# ---------------------------------------------------------------- settings

DEFAULT_CONFIG = {
    "name": "Vega",
    "model": "vega",                     # your Ollama model (fast; also used to understand commands)
    "chat_model": "auto",                # "auto" = pick the best brain for each question; "" = always "model";
                                         # or a model name like "gemma3:4b" to always use that one for chatting
    "smart_model": "",                   # the thinking brain used by "auto" ("" = best one you have installed)
    "code_model": "qwen2.5-coder:3b",    # used for coding / Linux command questions
    "auto_code_model": True,             # switch to code_model by itself for code questions
    "whisper_model": "small.en",         # speech-to-text; small.en understands Indian accents much better than base.en
    "smart_commands": True,
    "understand_telugu": False,          # hear Telugu / Tenglish speech (turn on in Menu)
    "speak_telugu": False,               # speak answers in Telugu (needs internet)
    "telugu_voice": "te-IN-ShrutiNeural",  # or "te-IN-MohanNeural" for a male voice
    "telugu_model": "small",             # "small" (faster) or "medium" (better Telugu, slower)              # when a command isn't clear, ask the AI what you meant
    "wake_model": "base.en",             # model used only to hear "Hey Vega" (base.en copes with accents better than tiny.en)
    "wake_variants": [],                 # how Whisper hears your "Vega" (Menu -> Teach me your "Hey Vega")
    "voice_on": True,                    # read answers out loud
    "wake_word_on": False,               # listen for "Hey Vega" in the background
    "speech_rate": 1,                    # -10 (slow) to 10 (fast)
    "city": "Chennai",                   # default weather place (SRM Kattankulathur)
    "latitude": 12.8231,
    "longitude": 80.0442,
    "vm_name": "hemanth-server1",
    "study_nudge_time": "21:00",
    "morning_briefing_time": "07:30",    # daily briefing on screen and phone ("" = off)
    "internship_keywords": ["devops", "cloud computing", "linux"],         # if today's task isn't done by then, Vega reminds you ("" = off)
    "vboxmanage": "C:\\Program Files\\Oracle\\VirtualBox\\VBoxManage.exe",
    "documents_folder": "documents",
    "telegram_token": "",                # from @BotFather (see the setup guide)
    "telegram_chat_id": "",              # only this chat may talk to Vega
    "apps": {
        "notepad": "notepad.exe",
        "calculator": "calc.exe",
        "paint": "mspaint.exe",
        "file explorer": "explorer.exe",
        "explorer": "explorer.exe",
        "files": "explorer.exe",
        "task manager": "taskmgr.exe",
        "settings": "ms-settings:",
        "command prompt": "cmd.exe",
        "cmd": "cmd.exe",
        "powershell": "powershell.exe",
        "terminal": "wt.exe",
        "chrome": "chrome",
        "google chrome": "chrome",
        "brave": "brave",
        "edge": "msedge",
        "vs code": "code",
        "vscode": "code",
        "visual studio code": "code",
        "virtualbox": "C:\\Program Files\\Oracle\\VirtualBox\\VirtualBox.exe",
        "steam": "steam://open/main",
        "spotify": "spotify:",
        "whatsapp": "whatsapp:",
        "camera": "microsoft.windows.camera:",
        "word": "winword",
        "excel": "excel",
        "powerpoint": "powerpnt",
        "snipping tool": "snippingtool.exe"
    },
    "sites": {
        "youtube": "https://www.youtube.com",
        "google": "https://www.google.com",
        "gmail": "https://mail.google.com",
        "github": "https://github.com",
        "linkedin": "https://www.linkedin.com",
        "coursera": "https://www.coursera.org",
        "chatgpt": "https://chatgpt.com",
        "claude": "https://claude.ai",
        "lab log": LAB_LOG_URL,
        "lablog": LAB_LOG_URL,
        "my lab log": LAB_LOG_URL,
        "whatsapp web": "https://web.whatsapp.com",
        "instagram": "https://www.instagram.com",
        "netflix": "https://www.netflix.com",
        "maps": "https://maps.google.com",
        "google maps": "https://maps.google.com",
        "odysseus": "http://127.0.0.1:7000",
        "facebook": "https://www.facebook.com",
        "twitter": "https://x.com",
        "x": "https://x.com",
        "telegram": "https://web.telegram.org",
        "telegram web": "https://web.telegram.org",
        "amazon": "https://www.amazon.in",
        "flipkart": "https://www.flipkart.com",
        "google drive": "https://drive.google.com",
        "drive": "https://drive.google.com",
        "google calendar": "https://calendar.google.com",
        "calendar": "https://calendar.google.com",
        "google classroom": "https://classroom.google.com",
        "classroom": "https://classroom.google.com",
        "srm academia": "https://academia.srmist.edu.in",
        "academia": "https://academia.srmist.edu.in",
        "leetcode": "https://leetcode.com",
        "hackerrank": "https://www.hackerrank.com",
        "stack overflow": "https://stackoverflow.com",
        "reddit": "https://www.reddit.com",
        "wikipedia": "https://en.wikipedia.org",
        "outlook": "https://outlook.live.com",
        "spotify web": "https://open.spotify.com",
        "red hat sandbox": "https://developers.redhat.com/developer-sandbox",
        "azure portal": "https://portal.azure.com",
        "oracle cloud": "https://cloud.oracle.com"
    }
}


def read_json(name, default):
    try:
        with open(here(name), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(name, data):
    tmp = here(name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, here(name))


def strip_thinking(text):
    """Some models (like qwen3) 'think out loud' inside <think> tags first. Hide that."""
    return re.sub(r"<think>.*?(</think>|$)", "", text or "", flags=re.S).lstrip()


def load_config():
    """Read config.json, filling in anything missing from the defaults."""
    user = read_json("config.json", None)
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    if isinstance(user, dict):
        for k, v in user.items():
            if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                cfg[k].update({str(a).lower(): b for a, b in v.items()})
            else:
                cfg[k] = v
    if cfg.get("config_version", 1) < 2:  # upgrade older settings once
        if cfg.get("whisper_model") in ("base.en", "tiny.en"):
            cfg["whisper_model"] = "small.en"
        cfg["config_version"] = 2
    if cfg.get("config_version", 1) < 3:
        if cfg.get("wake_model") == "tiny.en":
            cfg["wake_model"] = "base.en"
        cfg["config_version"] = 3
    if cfg.get("config_version", 1) < 4:
        if not cfg.get("chat_model"):
            cfg["chat_model"] = "auto"  # new: switch brains by question
        cfg["config_version"] = 4
    write_json("config.json", cfg)  # adds any new settings to your file
    return cfg


def save_config_value(key, value):
    cfg = read_json("config.json", {}) or {}
    cfg[key] = value
    write_json("config.json", cfg)


# ---------------------------------------------------------------- helpers

NUMBER_WORDS = {
    "a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
    "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12,
    "thirteen": 13, "fourteen": 14, "fifteen": 15, "sixteen": 16, "seventeen": 17,
    "eighteen": 18, "nineteen": 19, "twenty": 20, "twenty five": 25, "thirty": 30,
    "forty": 40, "forty five": 45, "fifty": 50, "sixty": 60, "ninety": 90,
}


def to_number(word):
    word = word.lower().strip()
    if word.isdigit():
        return int(word)
    return NUMBER_WORDS.get(word)


def words_to_digits(text):
    """'at seven thirty pm' -> 'at 7 30 pm' (only for small number words)."""
    for w in sorted(NUMBER_WORDS, key=len, reverse=True):
        if w in ("a", "an"):
            continue
        text = re.sub(r"\b" + w + r"\b", str(NUMBER_WORDS[w]), text)
    return text


def clean_command(text):
    """Lower-case the text and drop 'hey vega', 'please', etc."""
    t = text.strip().lower()
    t = t.replace("’", "'").replace("‘", "'")
    t = re.sub(r"^(hey|hi|ok|okay|hello)[\s,]+", "", t)
    t = re.sub(r"^(vega|wega|vegas|veega)[\s,.!]*", "", t)
    t = re.sub(r"^(please|can you|could you|will you|would you)\s+", "", t)
    t = re.sub(r"^(please)\s+", "", t)
    t = re.sub(r"[\s,]*please$", "", t)
    t = re.sub(r"[?.!]+$", "", t).strip()
    return t


def fmt_time(dt):
    return dt.strftime("%I:%M %p").lstrip("0")


def fmt_day(dt):
    today = date.today()
    d = dt.date() if isinstance(dt, datetime) else dt
    if d == today:
        return "today"
    if d == today + timedelta(days=1):
        return "tomorrow"
    return d.strftime("%a %d %b")


def http_get(url, params=None, timeout=8):
    import requests  # imported here so the rest works even if it's missing
    r = requests.get(url, params=params, timeout=timeout, headers={"User-Agent": USER_AGENT})
    r.raise_for_status()
    return r


def keep_case(part, raw):
    """We match commands in lower case; this gives back the words as you typed them."""
    i = raw.lower().find(part.lower())
    return raw[i:i + len(part)] if part and i >= 0 else part


def reply(text, say=None, **extra):
    """A finished answer: text for the screen, and a (shorter) version to speak."""
    out = {"text": text, "say": say if say is not None else text}
    out.update(extra)
    return out


# ---------------------------------------------------------------- the brain

class Vega:
    def __init__(self):
        self.cfg = load_config()
        self.name = self.cfg["name"]
        self.lock = threading.RLock()
        self.history = self._load_history()
        self.diary_mode = False
        self.active_doc = None   # (name, text)
        self.stop_flag = threading.Event()
        os.makedirs(here(self.cfg["documents_folder"]), exist_ok=True)
        os.makedirs(here("diary"), exist_ok=True)

    # ---------------- memory
    def _load_history(self):
        data = read_json("memory.json", [])
        if not isinstance(data, list):
            return []
        return [m for m in data if isinstance(m, dict) and m.get("role") in ("user", "assistant") and m.get("content")]

    def _save_history(self):
        write_json("memory.json", self.history[-20:])

    def facts(self):
        try:
            with open(here("facts.txt"), "r", encoding="utf-8") as f:
                return [line.strip() for line in f if line.strip()]
        except OSError:
            return []

    def save_facts(self, facts):
        with open(here("facts.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(facts) + ("\n" if facts else ""))

    # ---------------- main entry
    def handle(self, text, source="laptop", on_token=None, spoken=False):
        """
        Understand one message and answer it.
        source: "laptop" or "phone".  on_token(text_so_far) streams AI replies.
        Returns {"text": ..., "say": ...}.
        """
        raw = (text or "").strip()
        if not raw:
            return reply("I didn't catch that.")
        t = clean_command(raw)

        if self.diary_mode:
            out = self.diary_command(t, raw)
            if out:
                return out
            for skill in (self.time_and_date, self.notebook):
                out = skill(t, raw)
                if out:
                    return out
            self.diary_append(raw)
            return self.chat(raw, source, on_token,
                             instruction="Hemanth is writing his diary and just told you this. "
                                         "Listen like a caring friend. Reply in 1 or 2 short sentences "
                                         "and ask one gentle question about his day. Don't give advice unless he asks.",
                             save=False)

        self._source = source
        out = self.run_skills(t, raw, source, on_token)
        if out is not None and not out.get("unknown"):
            return out
        unknown = out
        # Not a clear command. If it sounds like one (or speech may have misheard), ask the AI what was meant.
        if self.cfg.get("smart_commands", True) and self.sounds_like_command(t, spoken):
            fixed = self.understand(raw)
            if fixed and fixed.upper() != "CHAT":
                ft = clean_command(fixed)
                if ft and ft != t and self.routed_ok(raw, ft):
                    out = self.run_skills(ft, fixed, source, on_token, allow_unknown=False)
                    if out is not None:
                        out["text"] = f"(I understood: {fixed})\n" + out["text"]
                        return out
        if unknown is not None:
            return unknown
        return self.chat(raw, source, on_token)

    def speech_hint(self):
        """Words Whisper should expect: helps it hear names and app names in an Indian accent."""
        words = ["Hey Vega", "Hemanth", "WhatsApp", "Instagram", "YouTube", "VirtualBox", "Rocky Linux", "OpenShift",
                 "Kubernetes", "Coursera", "SRM", "remind me", "to-do list"]
        words += [c["name"] for c in self.load_contacts().values()][:30]
        return ", ".join(dict.fromkeys(words)) + "."

    ACTION_WORDS = re.compile(r"\b(cheyyi|cheyu|cheppu|pettu|chupinchu|teruvu|open|launch|start|run|play|call|ring|message|text|remind|reminder|alarm|wake|set|add|put|"
                              r"mark|tick|search|google|look up|show|check|turn|lock|stop|shut|close|weather|news|music|song|"
                              r"video|whatsapp|youtube|instagram|app|task|progress|todo|to-?do|diary|internships?)\b")

    # Commands that change something need proof in what he actually said, so the AI can't invent them.
    PROOF = [
        (r"^(remind|wake)", r"remind|reminder|alarm|wake|gurthu|gurtu|guruthu|lepu|lepa|lepandi|nidra"),
        (r"^add\b", r"\badd|to-?do|list|pettu|raasu|rasu|note"),
        (r"^mark\b", r"\bmark|done|finish|complete|ayipoy|aipoy|aindi|ayindi|tick"),
        (r"^i finished", r"finish|done|complete|ayipoy|aipoy|aindi|ayindi"),
        (r"^(call|video call)", r"call|ring|phone|kalupu|video"),
        (r"^chat with", r"chat|message|text|whatsapp|msg"),
        (r"^lock", r"\block"),
        (r"^(start|stop) my vm", r"\bvm\b|virtual|server|machine|rocky|linux"),
        (r"^quiz", r"quiz|test|question|prashn"),
        (r"^open my diary", r"diary|journal"),
    ]

    def routed_ok(self, raw, cmd):
        low = raw.lower()
        for form, proof in self.PROOF:
            if re.match(form, cmd):
                return bool(re.search(proof, low))
        return True

    def sounds_like_command(self, t, spoken):
        words = t.split()
        if not words or len(words) > 14:
            return False
        # "you are ...", "I am ...", "it is ..." are statements, not orders
        if re.match(r"^(you are|you're|youre|you were|i am|i'm|im|i was|it is|it's|its|that is|that's|this is|he is|she is|we are)\b", t) \
                and not re.search(r"\b(open|play|call|remind|search|start|stop|lock|add)\b", t):
            return False
        if re.match(r"^(who|what|why|how|when|where|explain|tell me|can you explain|is it|are you|do you)\b", t) and not self.ACTION_WORDS.search(t):
            return False
        return spoken or bool(self.ACTION_WORDS.search(t))

    def understand(self, raw):
        """Ask the AI to turn a messy or misheard sentence into one exact Vega command (or CHAT)."""
        import ollama
        names = sorted(set(list(self.cfg["apps"]) + list(self.cfg["sites"]) + [a["name"].lower() for a in self.app_index()]))[:150]
        contacts = [c["name"] for c in self.load_contacts().values()][:40]
        prompt = (
            "You turn Hemanth's message into ONE exact command for his assistant program. He may write in English, Telugu or "
            "Tenglish (Telugu in English letters, e.g. 'youtube open cheyyi' = 'open youtube', 'repu 7 ki amma ki call cheyyamani "
            "gurthu cheyyi' = 'remind me at 7 pm tomorrow to call amma'). His messages often come from "
            "speech-to-text with an Indian English accent, so words may be misheard (for example 'Oh, better Apple Music' "
            "means 'open apple music', 'call the car' may mean 'call akka').\n"
            "Reply with JSON only: {\"command\": \"...\"}\n"
            "Command forms (copy the form exactly, fill in the <...>):\n"
            "open <app or website> | play <song or video> | search google for <words> |\n"
            "remind me at <time> to <thing> | remind me in <n> minutes to <thing> | wake me up at <time> | my reminders |\n"
            "add <item> to my to-do list | my to-do list | mark <item> done |\n"
            "call <contact> on whatsapp | video call <contact> | chat with <contact> |\n"
            "weather | weather tomorrow | weather in <city> | news | tech news | cricket | good morning | internships |\n"
            "what's my task today | I finished today's task | my progress | what did I miss | quiz me |\n"
            "start my vm | stop my vm | battery | laptop status | lock my laptop | open my diary | what time is it\n"
            f"Apps and websites he has: {', '.join(names)}\n"
            f"His contacts: {', '.join(contacts) or 'none yet'}\n"
            "If the message is a normal question or conversation (not a request to do something), reply {\"command\": \"CHAT\"}.\n"
            "Never invent a command that is not in the list."
        )
        try:
            r = ollama.chat(model=self.cfg["model"], format="json", keep_alive="15m", options={"temperature": 0},
                            messages=[{"role": "system", "content": prompt}, {"role": "user", "content": raw}])
            content = r["message"]["content"] if isinstance(r, dict) else r.message.content
            cmd = str(json.loads(content).get("command", "")).strip()
            return cmd[:200] or None
        except Exception:
            return None

    def run_skills(self, t, raw, source, on_token, allow_unknown=True):
        """Try every skill. Returns an answer, or None if nothing matched."""
        skills = (self.help, self.briefing, self.internships, self.time_and_date, self.notebook, self.diary_command,
                  self.todo, self.tracking, self.reminders, self.contacts, self.vm, self.lock_screen, self.laptop_status,
                  self.weather, self.news, self.search_and_play, self.sites_command, self.documents,
                  self.open_thing, self.plan, self.wikipedia)
        self._allow_unknown = allow_unknown
        for skill in skills:
            try:
                out = skill(t, raw)
            except Exception as e:  # a skill failed (no internet, etc.)
                kind = type(e).__name__
                if "Connection" in kind or "Timeout" in kind or "SSL" in kind:
                    return reply("I couldn't reach the internet. Check your Wi-Fi and try again.")
                if isinstance(e, ModuleNotFoundError):
                    return reply(f"A part of me isn't installed ({e.name}). Double-click 'Install Vega.bat' once.",
                                 "A part of me isn't installed. Run Install Vega once.")
                return reply(f"Sorry, that didn't work: {e}", "Sorry, that didn't work. The details are on screen.")
            if out is None:
                continue
            if out.get("unknown") and not getattr(self, "_allow_unknown", True):
                return None
            if out.get("ask"):
                return self.chat(out["ask"], source, on_token, shown=raw, instruction=out.get("instruction"))
            return out
        return None

    # ---------------- AI chat
    def context_notes(self, source, instruction=None):
        now = datetime.now()
        notes = [f"Right now it is {now.strftime('%A %d %B %Y, %I:%M %p')}."]
        facts = self.facts()
        if facts:
            notes.append("Things I asked you to remember about me:\n- " + "\n- ".join(facts))
        today = self.plan_context()
        if today:
            notes.append(today)
        if self.active_doc:
            name, text = self.active_doc
            notes.append(f"I opened the document '{name}'. Its text (maybe cut short):\n\"\"\"\n{text}\n\"\"\"")
        notes.append(
            "Important: you cannot open apps, set reminders, change my to-do list or control my laptop yourself. "
            "Those only happen when my message is a command Vega's program understands, and then you never see it. "
            "So if I ask you to do one of those things, don't pretend you did it. Say it didn't work and suggest the exact words, "
            "for example: 'remind me at 7 pm to call Amma', 'add buy milk to my to-do list', 'open chrome', "
            "'start my VM', 'weather tomorrow', 'news', 'what's my task today'. I can also say 'help' to see everything.")
        if source == "phone":
            notes.append("I'm messaging you from my phone on Telegram, so keep replies short.")
        notes.append("I sometimes write in Telugu or Tenglish (Telugu in English letters, like 'naaku help cheyyi'). "
                     "Understand it, and always reply in simple English (English letters only, never Telugu script), because I read English best. "
                     + ("Your answers are turned into a Telugu voice by the app, so if I ask, yes, you can speak Telugu." if self.cfg.get("speak_telugu") else ""))
        if instruction:
            notes.append(instruction)
        return "\n\n".join(notes)

    # ---------------- which brain answers
    CODE_WORDS = re.compile(r"\b(code|coding|python|java|javascript|c\+\+|html|css|sql|bash|shell|script|function|"
                            r"program|error|bug|debug|traceback|exception|compile|syntax|regex|git|docker|yaml|json|"
                            r"api|command for|linux command|terminal|powershell|ansible|kubectl|oc |dnf|systemctl|"
                            r"chmod|grep|awk|sed)\b", re.I)

    SMART_PREFERENCE = ["gemma3:4b", "qwen2.5:7b", "llama3.1:8b", "qwen3:4b", "gemma3:12b", "mistral:7b", "qwen2.5:3b"]
    CODE_SIGNS = re.compile(r"```|\bdef |\bimport |#include|\bprintf\(|\bconsole\.log|=>|\};|\$ |\bsudo\b|"
                            r"\.(py|java|js|sh|cpp|c|html|css|sql|yaml|yml|json)\b|\b(dnf|yum|apt|ssh|vim|nano|pip|npm|"
                            r"mkdir|useradd|firewall-cmd|nmcli|lvcreate|pvcreate|vgcreate|crontab|tar)\b|permission denied|"
                            r"command not found|no such file|segmentation fault|stack trace", re.I)
    SMALL_TALK = re.compile(r"^(hi|hello|hey|hii+|good (morning|afternoon|evening|night)|thanks|thank you|ok|okay|"
                            r"bye|how are you|what'?s up|sup|nice|cool|great|lol|haha|yes|no|hmm+|gunnai|good)\b", re.I)
    THINK_WORDS = re.compile(r"\b(explain|what is|what are|what's the difference|difference|define|definition|why|how does|"
                             r"how do|how to|describe|compare|advantages|disadvantages|meaning|summari[sz]e|notes on|"
                             r"assignment|essay|question|answer|teach|learn|example|steps|plan|interview|resume|career|"
                             r"fundamentals|concept|theory|history|analy[sz]e|suggest|advice|should i)\b", re.I)

    def installed_models(self, fresh=False):
        import ollama
        now = time.time()
        cache = getattr(self, "_models_cache", None)
        if cache and not fresh and now - cache[0] < 60:
            return cache[1]
        try:
            names = [m.model for m in ollama.list().models]
        except Exception:
            names = cache[1] if cache else []
        self._models_cache = (now, names)
        return names

    def has_model(self, name):
        return bool(name) and any(self._same(n, name) for n in self.installed_models())

    @staticmethod
    def _same(a, b):
        a, b = a.lower(), b.lower()
        return a == b or a == b + ":latest" or b == a + ":latest"

    def smart_model(self):
        """The best 'thinking' brain he has installed (or the one set in settings)."""
        want = (self.cfg.get("smart_model") or "").strip()
        if want and self.has_model(want):
            return want
        for name in self.SMART_PREFERENCE:
            if self.has_model(name):
                return name
        return self.cfg.get("model") or "vega"

    def question_kind(self, text):
        """'code', 'think' (study / explain / long question) or 'quick' (small talk)."""
        t = (text or "").strip()
        if self.CODE_WORDS.search(t) or self.CODE_SIGNS.search(t):
            return "code"
        words = len(t.split())
        if self.active_doc or self.THINK_WORDS.search(t) or words > 14 or (t.endswith("?") and words > 5):
            return "think"
        if self.SMALL_TALK.match(t) or words <= 6:
            return "quick"
        return "think"

    def pick_model(self, text):
        """Choose which brain answers: fast Vega for small talk, the coder for code, the smart one for thinking."""
        main = self.cfg.get("model") or "vega"
        if self.diary_mode:
            return main
        chosen = (self.cfg.get("chat_model") or "").strip()
        code = (self.cfg.get("code_model") or "").strip()
        kind = self.question_kind(text)
        if kind == "code" and code and self.cfg.get("auto_code_model", True) and self.has_model(code):
            return code
        if chosen.lower() == "auto":
            return self.smart_model() if kind in ("think", "code") else main
        return chosen or main

    def personality(self):
        """Vega's personality (the SYSTEM text from her Modelfile), so other models act like Vega too."""
        if getattr(self, "_personality", None) is not None:
            return self._personality
        text = ""
        try:
            import ollama
            info = ollama.show(self.cfg.get("model") or "vega")
            text = (getattr(info, "system", None) or "") if not isinstance(info, dict) else (info.get("system") or "")
            if not text:
                mf = getattr(info, "modelfile", None) if not isinstance(info, dict) else info.get("modelfile")
                m = re.search(r'^SYSTEM\s+"""(.*?)"""', mf or "", re.S | re.M) or re.search(r"^SYSTEM\s+(.+)$", mf or "", re.M)
                text = m.group(1).strip() if m else ""
        except Exception:
            pass
        if not text:
            try:
                with open(here("Modelfile-full"), encoding="utf-8") as f:
                    m = re.search(r'SYSTEM\s+"""(.*?)"""', f.read(), re.S)
                    text = m.group(1).strip() if m else ""
            except OSError:
                pass
        self._personality = text or ("You are Vega, Hemanth's friendly personal assistant. Hemanth is a final-year "
                                     "SRM student learning Linux, OpenShift and cloud. Speak simple English, be warm and brief.")
        return self._personality

    def chat(self, text, source="laptop", on_token=None, shown=None, instruction=None, save=True):
        import ollama
        with self.lock:
            stamp = datetime.now().strftime("%d %b %Y, %I:%M %p")
            keep = 6 if self.active_doc else 14
            messages = [
                {"role": "user", "content": self.context_notes(source, instruction)},
                {"role": "assistant", "content": "Got it. I'll keep this in mind."},
            ] + self.history[-keep:] + [{"role": "user", "content": f"[{stamp}] {text}"}]
            self.stop_flag.clear()
            main = self.cfg.get("model") or "vega"
            model = self.pick_model(text)
            note = ""
            for attempt in (1, 2):
                msgs = messages if self._same(model, main) else [{"role": "system", "content": self.personality()}] + messages
                answer = ""
                try:
                    for part in ollama.chat(model=model, messages=msgs, stream=True, keep_alive="15m"):
                        piece = part["message"]["content"] if isinstance(part, dict) else part.message.content
                        answer += piece or ""
                        if on_token:
                            on_token(strip_thinking(answer))
                        if self.stop_flag.is_set():
                            answer += " …(stopped)"
                            break
                    break
                except Exception as e:
                    msg = str(e)
                    if "not found" in msg.lower() and not self._same(model, main) and attempt == 1:
                        note = f"\n\n(I couldn't find the model '{model}', so my normal brain answered. " \
                               f"To get it, run in PowerShell: ollama pull {model})"
                        model = main
                        continue
                    if "not found" in msg.lower():
                        return reply(f"I can't find the model '{main}'. In PowerShell run: "
                                     f"ollama create {main} -f Modelfile-full",
                                     "I can't find my model. The fix is on screen.")
                    return reply("I can't reach Ollama. Open the Ollama app (Start menu → Ollama) and try again.\n"
                                 f"(Details: {msg})", "I can't reach Ollama. Open the Ollama app and try again.")
            answer = strip_thinking(answer).strip() or "(no answer)"
            self.last_model = model
            if save:
                self.history.append({"role": "user", "content": f"[{stamp}] {shown or text}"})
                self.history.append({"role": "assistant", "content": answer})
                self._save_history()
            out = reply(answer + note, answer, kind="chat")
            out["model"] = model
            return out

    def stop(self):
        self.stop_flag.set()

    # ---------------- help, time
    def help(self, t, raw):
        if not re.search(r"^(help|what can you do|what do you do|your commands|show commands|commands)$", t):
            return None
        text = (
            "Here's what I can do. Just say or type it:\n"
            "• Chat: ask me anything, or say 'interview me on my resume'\n"
            "• Time: 'what time is it', 'what's the date'\n"
            "• Reminders: 'remind me at 7 pm to call Amma', 'remind me in 20 minutes to drink water', "
            "'wake me up at 6 am', 'my reminders', 'cancel reminder Amma'\n"
            "• My tasks: 'add submit lab record for tomorrow', 'add gym every day', 'add pay fees on 30 sep', "
            "'my tasks', 'tomorrow's tasks', 'mark gym done', 'delete pay fees'\n"
            "• WhatsApp: 'add contact Amma 98765 43210', 'call Amma on WhatsApp', 'chat with Ravi', 'my contacts'\n"
            "• Laptop: 'open chrome', 'open whatsapp', 'open instagram', 'play lofi music', 'search google for Rocky Linux', "
            "'what can you open', 'add site srm portal https://academia.srmist.edu.in', "
            "'battery', 'laptop status', 'lock my laptop'\n"
            "• Your VM: 'start my VM', 'stop my VM', 'is my VM running'\n"
            "• Morning: 'good morning' (weather, task, streak, reminders, news, internships), 'internships'\n"
            "• Web: 'weather', 'weather tomorrow', 'weather in Hyderabad', 'news', 'tech news', 'cricket', "
            "'who is APJ Abdul Kalam', 'tell me about Kubernetes'\n"
            "• Study plan: 'what's my task today', 'tomorrow's task', 'this week', 'quiz me', 'move my plan back 3 days'\n"
            "• Tracking: 'I finished today's task', 'mark week 1 day 3 done', 'undo today', 'my progress', 'what did I miss'\n"
            "• Diary: 'open my diary' (then talk, and say 'close diary'), 'diary: today was good', 'read my diary yesterday'\n"
            "• Documents: put files in the 'documents' folder, then 'list my documents', 'summarize resume', "
            "ask questions, then 'close document'\n"
            "• Notebook: 'remember that my best friend is Ravi', 'what do you remember about me', 'forget Ravi'"
        )
        return reply(text, "Here's everything I can do. It's on screen.")

    def time_and_date(self, t, raw):
        now = datetime.now()
        if re.search(r"\bwhat(?:'s| is)? (?:the )?time\b|\btime (?:is it|now)\b|^time$", t):
            return reply(f"It's {fmt_time(now)}.")
        if re.search(r"what(?:'s| is) (?:the |today'?s )?date|what day is (?:it|today)|^date$|today'?s date", t):
            return reply(f"Today is {now.strftime('%A, %d %B %Y')}.")
        return None

    # ---------------- notebook
    def notebook(self, t, raw):
        m = re.match(r"^remember\s+that[\s,:]+(.+)$", raw.strip(), flags=re.I) or \
            re.match(r"^(?:hey\s+)?vega[\s,]+remember\s+that[\s,:]+(.+)$", raw.strip(), flags=re.I)
        if m:
            fact = m.group(1).strip().rstrip(".!?")
            if not fact:
                return reply("What should I remember?")
            facts = self.facts()
            if fact.lower() not in (x.lower() for x in facts):
                facts.append(fact)
                self.save_facts(facts)
            return reply(f"Got it, I'll remember that {fact}.")
        if re.search(r"what do you (remember|know) about me", t):
            facts = self.facts()
            if not facts:
                return reply("My notebook about you is empty so far. Tell me things by saying: remember that...")
            return reply("Here's what I've noted about you:\n- " + "\n- ".join(facts),
                         f"I have {len(facts)} notes about you. They're on screen.")
        m = re.match(r"^forget(?:\s+about|\s+that)?[\s,:]+(.+)$", t)
        if m and not re.search(r"\b(document|doc|file|pdf|reminder)\b", t):
            word = m.group(1).strip()
            facts = self.facts()
            kept = [x for x in facts if word not in x.lower()]
            removed = len(facts) - len(kept)
            self.save_facts(kept)
            if removed == 0:
                return reply(f"I didn't have anything noted about {word}.")
            return reply(f"Done. I forgot {removed} note{'s' if removed != 1 else ''} about {word}.")
        return None

    # ---------------- reminders
    def parse_when(self, body):
        """Find a time in the text. Returns (datetime or None, text without the time part)."""
        now = datetime.now()
        b = " " + words_to_digits(body.lower()) + " "
        b = b.replace("half an hour", "30 minutes").replace("half hour", "30 minutes")
        b = b.replace("o'clock", "").replace("a.m.", "am").replace("p.m.", "pm").replace("a. m.", "am").replace("p. m.", "pm")

        m = re.search(r"\bin\s+(\d+|a|an)\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)\b", b)
        if m:
            n = 1 if m.group(1) in ("a", "an") else int(m.group(1))
            unit = m.group(2)
            delta = timedelta(hours=n) if unit.startswith("h") else (timedelta(seconds=n) if unit.startswith("s") else timedelta(minutes=n))
            rest = (b[:m.start()] + " " + b[m.end():])
            return now + delta, rest

        day_offset = 0
        dm = re.search(r"\b(tomorrow|tonight|today|this evening|this morning)\b", b)
        if dm:
            if dm.group(1) == "tomorrow":
                day_offset = 1
            b = b[:dm.start()] + " " + b[dm.end():]

        m = re.search(r"(?:\bat\s+|\bfor\s+|^\s*|\s)(\d{1,2})(?:[:.\s](\d{2}))?\s*(am|pm)\b", b)
        m24 = None if m else re.search(r"\bat\s+(\d{1,2})(?:[:.](\d{2}))?\b", b)
        mm = m or m24
        if not mm:
            return None, body
        hour = int(mm.group(1))
        minute = int(mm.group(2) or 0)
        if hour > 23 or minute > 59:
            return None, body
        ampm = m.group(3) if m else None
        candidates = []
        if ampm:
            h = hour % 12 + (12 if ampm == "pm" else 0)
            candidates = [h]
        elif hour > 12 or hour == 0:
            candidates = [hour]
        else:
            evening = dm and dm.group(1) in ("tonight", "this evening")
            candidates = [hour % 12 + 12] if evening else [hour % 12, hour % 12 + 12]
        base_day = now.date() + timedelta(days=day_offset)
        best = None
        for h in candidates:
            when = datetime.combine(base_day, datetime.min.time()).replace(hour=h, minute=minute)
            if day_offset == 0 and when <= now:
                continue
            best = when if best is None or when < best else best
        if best is None:  # the time already passed today -> tomorrow
            h = candidates[0]
            best = datetime.combine(now.date() + timedelta(days=1), datetime.min.time()).replace(hour=h, minute=minute)
        rest = b[:mm.start()] + " " + b[mm.end():]
        return best, rest

    @staticmethod
    def tidy_reminder_text(rest):
        r = re.sub(r"\s+", " ", rest).strip(" ,.")
        r = re.sub(r"^(to|that|about|me to|me that|me about)\s+", "", r)
        r = re.sub(r"\s+(at|on|for|by)$", "", r)
        return r.strip(" ,.")

    def reminders(self, t, raw):
        items = read_json("reminders.json", [])
        if not isinstance(items, list):
            items = []

        m = re.match(r"^(?:set (?:an |a |my )?alarm|wake me(?: up)?)\s*(?:for|at)?\s*(.*)$", t)
        if m:
            when, _ = self.parse_when("at " + m.group(1) if m.group(1) and not m.group(1).startswith("in ") else m.group(1))
            if not when:
                return reply("What time? Say something like: wake me up at 6 am.")
            return self._add_reminder(items, when, "Alarm: time to wake up!" if "wake" in t else "Alarm")

        m = re.match(r"^remind me\s+(.+)$", t)
        if m:
            when, rest = self.parse_when(m.group(1))
            if not when:
                return reply("When should I remind you? Say it like: remind me at 7 pm to call Amma, "
                             "or remind me in 20 minutes to drink water.",
                             "When should I remind you? Say a time like 7 pm, or in 20 minutes.")
            text = keep_case(self.tidy_reminder_text(rest), raw) or "Reminder"
            return self._add_reminder(items, when, text)

        if re.search(r"^(what are |show |list |read )?(all )?(my )?(reminders|alarms)$|any reminders|do i have (any )?reminders", t):
            upcoming = sorted([r for r in items if not r.get("done")], key=lambda r: r["when"])
            if not upcoming:
                return reply("You have no reminders.")
            lines = [f"{i}. {fmt_day(datetime.fromisoformat(r['when'])).capitalize()} at "
                     f"{fmt_time(datetime.fromisoformat(r['when']))}: {r['text']}" for i, r in enumerate(upcoming, 1)]
            return reply("Your reminders:\n" + "\n".join(lines), f"You have {len(upcoming)} reminder{'s' if len(upcoming) != 1 else ''}. They're on screen.")

        m = re.match(r"^(?:cancel|delete|remove|clear)\s+(all\s+)?(?:my\s+|the\s+)?(?:reminders?|alarms?)(?:\s+(?:about|for|to|called)?\s*(.+))?$", t)
        if m:
            upcoming = [r for r in items if not r.get("done")]
            if m.group(1) or not m.group(2):
                if not m.group(1) and len(upcoming) > 1:
                    return reply("Which one? Say 'cancel reminder' and a word from it, or 'cancel all reminders'.")
                write_json("reminders.json", [r for r in items if r.get("done")])
                return reply(f"Cancelled {len(upcoming)} reminder{'s' if len(upcoming) != 1 else ''}.")
            word = m.group(2).strip()
            hit = [r for r in upcoming if word in r["text"].lower()]
            if not hit:
                return reply(f"I couldn't find a reminder about {word}.")
            ids = {r["id"] for r in hit}
            write_json("reminders.json", [r for r in items if r["id"] not in ids])
            return reply(f"Cancelled: {hit[0]['text']}" + (f" (and {len(hit) - 1} more)" if len(hit) > 1 else ""))
        return None

    def _add_reminder(self, items, when, text):
        items.append({"id": f"r{int(time.time() * 1000)}", "when": when.isoformat(timespec="seconds"),
                      "text": text[:200], "done": False})
        write_json("reminders.json", items[-200:])
        text_show = f"Okay. I'll remind you {fmt_day(when)} at {fmt_time(when)}: {text}"
        return reply(text_show + "\n(I can only remind you while I'm running. Turn on 'Start with Windows' so I'm always on.)",
                     text_show)

    def due_reminders(self):
        """Called every few seconds. Returns reminders that are due and marks them done."""
        items = read_json("reminders.json", [])
        if not isinstance(items, list) or not items:
            return []
        now = datetime.now()
        due = []
        for r in items:
            if r.get("done"):
                continue
            try:
                when = datetime.fromisoformat(r["when"])
            except (KeyError, ValueError):
                r["done"] = True
                continue
            if when <= now:
                r["done"] = True
                late = (now - when).total_seconds() > 120
                due.append({"text": r["text"], "when": when, "late": late})
        if due:
            keep_from = now - timedelta(days=7)
            items = [r for r in items if not r.get("done") or datetime.fromisoformat(r["when"]) > keep_from]
            write_json("reminders.json", items)
        return due

    # ---------------- my tasks (to-do list with dates and repeats; tasks.json)
    WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}

    def tasks_data(self):
        data = read_json("tasks.json", None)
        if not isinstance(data, dict):
            old = read_json("todo.json", [])  # bring in the old simple to-do list once
            items = [{"id": f"t{i}{int(time.time())}", "text": str(x), "date": None, "repeat": "none"}
                     for i, x in enumerate(old if isinstance(old, list) else [])]
            data = {"items": items, "done": {}}
            write_json("tasks.json", data)
        data.setdefault("items", [])
        data.setdefault("done", {})
        return data

    def save_tasks(self, data):
        keep = (date.today() - timedelta(days=60)).isoformat()
        data["done"] = {k: v for k, v in data["done"].items() if k >= keep and v}
        write_json("tasks.json", data)

    def task_done(self, data, task, day):
        if task.get("repeat", "none") != "none":
            return task["id"] in data["done"].get(day, [])
        return any(task["id"] in v for v in data["done"].values())

    def task_applies(self, task, d):
        rep = task.get("repeat", "none")
        if rep == "daily":
            return True
        if rep == "weekdays":
            return d.weekday() < 5
        if rep == "weekly":
            start = date.fromisoformat(task["date"]) if task.get("date") else d
            return d.weekday() == start.weekday() and d >= start
        return True

    def tasks_for(self, d):
        """[(task, done, tag)] for day d: repeating tasks, tasks dated d, undated open tasks, and overdue ones (for today)."""
        data = self.tasks_data()
        day, today = d.isoformat(), date.today()
        out = []
        for tk in data["items"]:
            rep = tk.get("repeat", "none")
            if rep != "none":
                if self.task_applies(tk, d):
                    tag = {"daily": "every day", "weekdays": "weekdays"}.get(rep) or \
                        ("every " + self.WEEKDAYS[date.fromisoformat(tk["date"]).weekday()].capitalize() if tk.get("date") else rep)
                    out.append((tk, self.task_done(data, tk, day), tag))
                continue
            done = self.task_done(data, tk, day)
            if not tk.get("date"):
                if d == today and (not done or tk["id"] in data["done"].get(day, [])):
                    out.append((tk, done, ""))
                continue
            td = date.fromisoformat(tk["date"])
            if td == d:
                out.append((tk, done, ""))
            elif d == today and td < d and not done:
                out.append((tk, done, "overdue, " + td.strftime("%a %d %b")))
        return out

    def upcoming_tasks(self, days=7):
        data = self.tasks_data()
        today = date.today()
        out = []
        for tk in data["items"]:
            if tk.get("repeat", "none") == "none" and tk.get("date"):
                td = date.fromisoformat(tk["date"])
                if today < td <= today + timedelta(days=days) and not self.task_done(data, tk, tk["date"]):
                    out.append((td, tk))
        return sorted(out, key=lambda x: x[0])

    def parse_task_when(self, text):
        """Find 'tomorrow', 'on friday', 'on 30 sep', 'every day', 'weekdays', 'every monday'. Returns (date, repeat, rest)."""
        today = date.today()
        t = " " + text + " "

        def cut(m):
            return (t[:m.start()] + " " + t[m.end():]).strip()

        m = re.search(r"\s(?:every\s?day|daily|everyday)\b", t)
        if m:
            return None, "daily", cut(m)
        m = re.search(r"\s(?:every\s+weekday|on\s+weekdays|weekdays|every\s+week\s?day)\b", t)
        if m:
            return None, "weekdays", cut(m)
        m = re.search(r"\s(?:every|each)\s+(" + "|".join(self.WEEKDAYS) + r")\b", t)
        if m:
            wd = self.WEEKDAYS.index(m.group(1))
            return today + timedelta(days=(wd - today.weekday()) % 7), "weekly", cut(m)
        m = re.search(r"\s(?:for\s+|on\s+|by\s+)?(day after tomorrow|tomorrow|today|tonight)\b", t)
        if m:
            off = {"today": 0, "tonight": 0, "tomorrow": 1, "day after tomorrow": 2}[m.group(1)]
            return today + timedelta(days=off), "none", cut(m)
        m = re.search(r"\s(?:on\s+|by\s+|for\s+|this\s+|next\s+)(" + "|".join(self.WEEKDAYS) + r")\b", t)
        if m:
            wd = self.WEEKDAYS.index(m.group(1))
            return today + timedelta(days=(wd - today.weekday()) % 7 or 7), "none", cut(m)
        mon = r"(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*"
        m = re.search(r"\s(?:on\s+|by\s+|for\s+)?(\d{1,2})(?:st|nd|rd|th)?\s+(?:of\s+)?" + mon + r"\b", t) or \
            re.search(r"\s(?:on\s+|by\s+|for\s+)?" + mon + r"\s+(\d{1,2})(?:st|nd|rd|th)?\b", t)
        if m:
            g = m.groups()
            dnum, mname = (int(g[0]), g[1]) if g[0].isdigit() else (int(g[1]), g[0])
            try:
                d = date(today.year, self.MONTHS[mname[:3]], dnum)
                if d < today:
                    d = date(today.year + 1, d.month, d.day)
                return d, "none", cut(m)
            except ValueError:
                pass
        m = re.search(r"\s(?:on\s+|by\s+|for\s+)(\d{1,2})[/-](\d{1,2})\b", t)
        if m:
            try:
                d = date(today.year, int(m.group(2)), int(m.group(1)))
                if d < today:
                    d = date(today.year + 1, d.month, d.day)
                return d, "none", cut(m)
            except ValueError:
                pass
        return None, "none", text.strip()

    def tasks_view(self, d):
        rows = self.tasks_for(d)
        heading = "Today" if d == date.today() else ("Tomorrow" if d == date.today() + timedelta(days=1) else d.strftime("%A"))
        lines = [f"{heading}, {d.strftime('%a %d %b')}"]
        plan = self.load_plan()
        if plan:
            idx = (d - date.fromisoformat(plan["start"])).days - self.plan_shift()
            pd = self.plan_day(plan, idx)
            if pd:
                lines.append(f"Study: {pd['label']}, {pd['title']}" + (" ✓" if self.is_done(idx) else ""))
        if rows:
            lines.append("My tasks:")
            for i, (tk, done, tag) in enumerate(rows, 1):
                lines.append(f"  {i}. {'✓' if done else '○'} {tk['text']}" + (f"  ({tag})" if tag else ""))
        else:
            lines.append("My tasks: nothing yet. Add one: add submit lab record for tomorrow")
        if d == date.today():
            up = self.upcoming_tasks()
            if up:
                lines.append("Coming up:")
                lines += [f"  {td.strftime('%a %d %b')}: {tk['text']}" for td, tk in up[:6]]
        left = [tk["text"] for tk, done, _ in rows if not done]
        say = (f"{heading} you have {len(left)} task{'s' if len(left) != 1 else ''} left: " + ", ".join(left[:4]) + ".") if left \
            else f"All your tasks for {heading.lower()} are done." if rows else f"You have no tasks for {heading.lower()}."
        return reply("\n".join(lines), say)

    def find_task(self, target, rows_today):
        target = target.strip().lower()
        if target.isdigit() and 1 <= int(target) <= len(rows_today):
            return rows_today[int(target) - 1][0]
        data = self.tasks_data()
        items = data["items"]
        low = [x["text"].lower() for x in items]
        for i, x in enumerate(low):
            if target == x:
                return items[i]
        for i, x in enumerate(low):
            if len(target) >= 3 and (target in x or x in target):
                return items[i]
        close = difflib.get_close_matches(target, low, n=1, cutoff=0.6)
        return items[low.index(close[0])] if close else None

    def todo(self, t, raw):
        LIST = r"(?:to-?do(?:\s+list)?|todo|to do(?:\s+list)?|list|tasks?|task list)"
        if re.match(r"^add\s+(?:a\s+)?(?:site|website|link|contact)\b", t):
            return None

        # add
        m = re.match(r"^(?:add|put)\s+(?:a\s+)?(?:task\s+)?(.+?)\s+(?:to|on|in)\s+(?:my\s+|the\s+)?" + LIST + r"$", t) or \
            re.match(r"^(?:add\s+(?:a\s+)?task|new task|create (?:a\s+)?task|to-?do|todo)[:\s]+(.+)$", t) or \
            re.match(r"^(?:add|put)\s+(.+?\s(?:tomorrow|today|every\s?day|daily|everyday|weekdays|every \w+day|on \w+day|on \d{1,2}.*|by \w+day|for tomorrow))$", t)
        if m:
            when, rep, text = self.parse_task_when(m.group(1))
            text = keep_case(text.strip(" ,.:"), raw) or "Task"
            text = re.sub(r"\s+(?:to|on|in)\s+(?:my\s+|the\s+)?(?:to-?do(?:\s+list)?|list|tasks?)$", "", text, flags=re.I)
            data = self.tasks_data()
            data["items"].append({"id": "t" + format(int(time.time() * 1000), "x"), "text": text[:200],
                                  "date": when.isoformat() if when else None, "repeat": rep})
            data["items"] = data["items"][-300:]
            self.save_tasks(data)
            when_txt = {"daily": "every day", "weekdays": "on weekdays"}.get(rep) or \
                (f"every {when.strftime('%A')}" if rep == "weekly" else (fmt_day(when) if when else "no date"))
            return reply(f"Added: {text}, {when_txt}.", f"Added {text}, {when_txt}.")

        # show
        if re.search(r"^(?:what(?:'s| is| are)\s+)?(?:on\s+)?(?:my\s+|the\s+)?(?:to-?do(?:\s+list)?|todo|to do(?:\s+list)?|tasks|task list)(?:\s+for)?(?:\s+today)?$", t) or \
                re.search(r"^(?:today'?s|my today'?s) tasks$|^what (?:do i|should i) (?:have to|need to) do(?: today)?$|^my day$|^plan for today$", t):
            return self.tasks_view(date.today())
        if re.search(r"^(?:what(?:'s| is| are)\s+)?(?:my\s+)?(?:tomorrow'?s tasks|tasks (?:for )?tomorrow|to-?do (?:for )?tomorrow)$|^what do i have (?:to do )?tomorrow$", t):
            return self.tasks_view(date.today() + timedelta(days=1))

        # clear
        if re.match(r"^(?:clear|empty|reset)\s+(?:my\s+|the\s+)?" + LIST + r"$", t):
            self.save_tasks({"items": [], "done": {}})
            return reply("All your tasks are cleared.")

        data = self.tasks_data()
        if not data["items"]:
            return None
        rows = self.tasks_for(date.today())

        # delete
        m = re.match(r"^(?:delete|remove|cancel)\s+(?:the\s+|my\s+)?(?:task\s+)?(.+?)(?:\s+(?:from|off)\s+(?:my\s+|the\s+)?" + LIST + r")?$", t)
        if m and not re.search(r"\b(reminder|contact|site|website|document|note)\b", t):
            tk = self.find_task(m.group(1), rows)
            if tk:
                data["items"] = [x for x in data["items"] if x["id"] != tk["id"]]
                for k in data["done"]:
                    data["done"][k] = [x for x in data["done"][k] if x != tk["id"]]
                self.save_tasks(data)
                return reply(f"Deleted: {tk['text']}.")
            return None

        # untick
        m = re.match(r"^(?:untick|uncheck|unmark)\s+(.+)$", t) or re.match(r"^(.+?)\s+(?:is\s+)?not done$", t)
        if m:
            tk = self.find_task(m.group(1), rows)
            if tk:
                for k in data["done"]:
                    data["done"][k] = [x for x in data["done"][k] if x != tk["id"]]
                self.save_tasks(data)
                return reply(f"Okay, {tk['text']} is not done.")
            return None

        # done
        m = re.match(r"^(?:mark|tick|tick off|check off|cross off|finished|finish|done with|done|i finished|i did|i've done|i have done|i completed|completed)\s+(.+?)"
                     r"(?:\s+(?:as\s+)?(?:done|complete|completed|finished|off))?(?:\s+(?:from|on)\s+(?:my\s+|the\s+)?" + LIST + r")?$", t) or \
            re.match(r"^(.+?)\s+(?:is\s+)?(?:done|finished|completed)$", t)
        if m:
            target = m.group(1).strip()
            if re.fullmatch(r"(?:today'?s|yesterday'?s|my|the)?\s*(?:task|study|lesson|studies)|today|yesterday|day\s*\w+|week.*|w\d.*", target):
                return None  # that's about the study plan
            tk = self.find_task(target, rows)
            if not tk:
                return None
            day = date.today().isoformat()
            if tk["id"] not in data["done"].setdefault(day, []):
                data["done"][day].append(tk["id"])
            self.save_tasks(data)
            left = [x["text"] for x, done, _ in self.tasks_for(date.today()) if not done]
            return reply(f"Done: {tk['text']}. " + (f"{len(left)} left today." if left else "Everything for today is done!"),
                         f"Nice. {tk['text']} is done.")
        return None

    # ---------------- laptop: VM, lock, status
    def _vboxmanage(self):
        p = self.cfg.get("vboxmanage", "")
        if p and os.path.exists(p):
            return p
        return shutil.which("VBoxManage") or shutil.which("vboxmanage")

    def vm(self, t, raw):
        VM = r"(?:vm|v\.m\.|virtual machine|server|rocky|rocky linux|linux vm|linux server|lab vm|lab server)"
        start = re.search(r"\b(?:start|boot|turn on|power on|open|run|launch)\s+(?:up\s+)?(?:my\s+|the\s+)?" + VM + r"\b", t)
        stop = re.search(r"\b(?:stop|shut ?down|shutdown|turn off|power off|close)\s+(?:my\s+|the\s+)?" + VM + r"\b", t)
        status = re.search(r"\bis\s+(?:my\s+|the\s+)?" + VM + r"\s+(?:running|on|up)\b|\b" + VM + r" status\b", t)
        if not (start or stop or status):
            return None
        vbox = self._vboxmanage()
        name = self.cfg["vm_name"]
        if not vbox:
            return reply("I can't find VirtualBox's VBoxManage.exe. Check the 'vboxmanage' path in config.json.")

        def run(*args):
            r = subprocess.run([vbox, *args], capture_output=True, text=True, timeout=60, creationflags=NO_WINDOW)
            return r.returncode, (r.stdout + r.stderr)

        code, out = run("list", "runningvms")
        running = f'"{name}"' in out
        if status:
            return reply(f"Yes, {name} is running." if running else f"No, {name} is off.")
        if start:
            if running:
                return reply(f"{name} is already running.")
            code, out = run("startvm", name, "--type", "gui")
            if code != 0:
                return reply(f"I couldn't start {name}.\n{out.strip()[:400]}", f"I couldn't start {name}. The error is on screen.")
            return reply(f"Starting {name}. Give it about a minute to boot.")
        if not running:
            return reply(f"{name} is already off.")
        code, out = run("controlvm", name, "acpipowerbutton")
        if code != 0:
            return reply(f"I couldn't shut down {name}.\n{out.strip()[:400]}", f"I couldn't shut down {name}.")
        return reply(f"Shutting down {name} safely (like pressing its power button).")

    def lock_screen(self, t, raw):
        if not re.search(r"\block\s+(?:my\s+|the\s+)?(?:laptop|computer|pc|screen|system)\b", t):
            return None
        if not IS_WINDOWS:
            return reply("Locking only works on Windows.")
        subprocess.Popen(["rundll32.exe", "user32.dll,LockWorkStation"], creationflags=NO_WINDOW)
        return reply("Locking your laptop.")

    def laptop_status(self, t, raw):
        want_batt = re.search(r"\bbattery\b|\bcharging\b|\bcharge\b", t)
        want_all = re.search(r"(laptop|system|computer|pc) (status|health|stats)|how(?:'s| is) my (laptop|computer|pc|system)|\bcpu\b|\bram\b|disk space|storage left|free space", t)
        if not (want_batt or want_all):
            return None
        import psutil
        lines = []
        b = psutil.sensors_battery()
        if b:
            state = "charging" if b.power_plugged else "on battery"
            extra = ""
            if not b.power_plugged and b.secsleft not in (psutil.POWER_TIME_UNLIMITED, psutil.POWER_TIME_UNKNOWN) and b.secsleft > 0:
                extra = f", about {b.secsleft // 3600} h {b.secsleft % 3600 // 60} min left"
            lines.append(f"Battery: {round(b.percent)}% ({state}{extra})")
        if want_all:
            cpu = psutil.cpu_percent(interval=0.5)
            mem = psutil.virtual_memory()
            disk = psutil.disk_usage("C:\\" if IS_WINDOWS else "/")
            lines.append(f"CPU: {cpu:.0f}% busy")
            lines.append(f"RAM: {mem.used / 2**30:.1f} of {mem.total / 2**30:.1f} GB used ({mem.percent:.0f}%)")
            lines.append(f"Disk C: {disk.free / 2**30:.0f} GB free of {disk.total / 2**30:.0f} GB")
            top = []
            for p in psutil.process_iter(["name", "memory_info"]):
                try:
                    top.append((p.info["memory_info"].rss, p.info["name"]))
                except Exception:
                    pass
            top.sort(reverse=True)
            names = []
            for rss, n in top:
                if n and n not in names:
                    names.append(n)
                if len(names) == 3:
                    break
            if names:
                lines.append("Using the most RAM: " + ", ".join(names))
        if not lines:
            return reply("I couldn't read the battery. This computer may not report it.")
        return reply("\n".join(lines), ". ".join(lines[:3]) + ".")

    # ---------------- web: weather, news, wikipedia
    WMO = {0: "clear sky", 1: "mostly clear", 2: "partly cloudy", 3: "cloudy", 45: "foggy", 48: "foggy",
           51: "light drizzle", 53: "drizzle", 55: "heavy drizzle", 56: "freezing drizzle", 57: "freezing drizzle",
           61: "light rain", 63: "rain", 65: "heavy rain", 66: "freezing rain", 67: "freezing rain",
           71: "light snow", 73: "snow", 75: "heavy snow", 77: "snow grains", 80: "light showers",
           81: "showers", 82: "heavy showers", 85: "snow showers", 86: "snow showers",
           95: "thunderstorm", 96: "thunderstorm with hail", 99: "thunderstorm with hail"}

    def weather(self, t, raw):
        if not re.search(r"\bweather\b|\btemperature\b|\bwill it rain\b|\bis it (?:going to )?rain|\bforecast\b|\bhow hot\b|\bhow cold\b|\bumbrella\b", t):
            return None
        tomorrow = "tomorrow" in t
        city, lat, lon = self.cfg["city"], self.cfg["latitude"], self.cfg["longitude"]
        m = re.search(r"\b(?:in|at|for)\s+([a-z][a-z .'-]{1,40}?)(?:\s+(?:today|tomorrow|now|right now|this week))?$", t)
        if m and m.group(1).strip() not in ("today", "tomorrow", "now", "this week") and not m.group(1).startswith(("the ", "this ", "my ")):
            place = m.group(1).strip()
            g = http_get("https://geocoding-api.open-meteo.com/v1/search",
                         {"name": place, "count": 1, "language": "en", "format": "json"}).json()
            res = (g or {}).get("results") or []
            if not res:
                return reply(f"I couldn't find a place called {place}.")
            city = res[0]["name"] + (f", {res[0].get('admin1')}" if res[0].get("admin1") else "")
            lat, lon = res[0]["latitude"], res[0]["longitude"]
        data = http_get("https://api.open-meteo.com/v1/forecast", {
            "latitude": lat, "longitude": lon, "timezone": "auto", "forecast_days": 2,
            "current": "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m",
            "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max",
        }).json()
        d = data["daily"]
        i = 1 if tomorrow else 0
        day_line = (f"{'Tomorrow' if tomorrow else 'Today'} in {city}: {self.WMO.get(d['weather_code'][i], 'mixed weather')}, "
                    f"{round(d['temperature_2m_min'][i])} to {round(d['temperature_2m_max'][i])}°C, "
                    f"{d['precipitation_probability_max'][i] or 0}% chance of rain.")
        if tomorrow:
            return reply(day_line, day_line.replace("°C", " degrees"))
        c = data["current"]
        now_line = (f"Right now: {round(c['temperature_2m'])}°C (feels like {round(c['apparent_temperature'])}°C), "
                    f"{self.WMO.get(c['weather_code'], 'mixed weather')}, humidity {c['relative_humidity_2m']}%, "
                    f"wind {round(c['wind_speed_10m'])} km/h.")
        rain = d["precipitation_probability_max"][0] or 0
        tip = " Take an umbrella." if rain >= 50 else ""
        return reply(day_line + "\n" + now_line + tip,
                     f"In {city.split(',')[0]} it's {round(c['temperature_2m'])} degrees and {self.WMO.get(c['weather_code'], 'mixed')}. "
                     f"Today {round(d['temperature_2m_min'][0])} to {round(d['temperature_2m_max'][0])} degrees, {rain}% chance of rain.{tip}")

    def fetch_news(self, topic=None, n=6):
        """Latest headlines from Google News (India). Returns [(title, link)]."""
        if topic:
            url = ("https://news.google.com/rss/search?q=" + urllib.parse.quote(topic + " when:1d") +
                   "&hl=en-IN&gl=IN&ceid=IN:en")
        else:
            url = "https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en"
        root = ET.fromstring(http_get(url).content)
        items = []
        for it in root.iter("item"):
            title = (it.findtext("title") or "").strip()
            link = (it.findtext("link") or "").strip()
            if " - " in title:
                title, source = title.rsplit(" - ", 1)
                title = f"{title} ({source})"
            if title:
                items.append((title, link))
            if len(items) == n:
                break
        return items

    # ---------------- internships (live search pages, always current, free)
    def internship_links(self):
        words = self.cfg.get("internship_keywords") or ["devops", "cloud computing", "linux"]
        shala = [(f"Internshala: {w} internships", "https://internshala.com/internships/keywords-" + urllib.parse.quote(w.replace(" ", "-")) + "/")
                 for w in words[:3]]
        linkedin = ("LinkedIn: DevOps / cloud intern roles in India, posted this week",
                    "https://www.linkedin.com/jobs/search/?keywords=" + urllib.parse.quote("devops OR cloud intern") +
                    "&location=India&f_TPR=r604800")
        naukri = ("Naukri: DevOps internships", "https://www.naukri.com/devops-internship-jobs")
        return shala[:1] + [linkedin, naukri] + shala[1:]

    def internships(self, t, raw):
        if not re.search(r"\b(internships?|intern jobs?|job openings|fresher jobs)\b", t):
            return None
        links = self.internship_links()
        if getattr(self, "_source", "laptop") == "laptop":
            for _, url in links[:3]:
                webbrowser.open(url)
            head = "Opened the top searches in your browser. All the live searches (updated by the sites every day):"
        else:
            head = "Live internship searches (updated by the sites every day):"
        return reply(head + "\n" + "\n".join(f"- {name}\n  {url}" for name, url in links) +
                     "\nTip: apply to ones asking for Linux, Docker or AWS, and note which skills repeat.",
                     "I opened internship searches in your browser.")

    # ---------------- morning briefing (free: all from your laptop + free sources)
    def morning_briefing(self):
        now = datetime.now()
        lines = [f"Good morning, Hemanth! It's {now.strftime('%A, %d %B')}.", ""]
        say = ["Good morning, Hemanth."]
        try:
            w = self.weather("weather", "weather")
            lines.append("Weather: " + w["text"].split("\n")[0])
            say.append(w["say"].split(" Today")[0].rstrip(".") + ".")
        except Exception:
            lines.append("Weather: couldn't get it (no internet?).")
        plan = self.load_plan()
        if plan:
            idx = self.today_index(plan)
            d = self.plan_day(plan, idx)
            if d:
                done = self.is_done(idx)
                cur, _ = self.streaks(idx)
                missed = self.missed(plan, idx)
                lines.append(f"Study: {d['label']}, {d['title']}" + (" (done)" if done else "") +
                             f". Streak: {cur} day{'s' if cur != 1 else ''}." +
                             (f" Carried over: {len(missed)}." if missed else ""))
                say.append(f"Today's task is {d['title']}.")
        items = read_json("reminders.json", [])
        today = [r for r in items if isinstance(r, dict) and not r.get("done")
                 and r.get("when", "")[:10] == now.date().isoformat()]
        if today:
            lines.append("Reminders today: " + "; ".join(
                f"{fmt_time(datetime.fromisoformat(r['when']))} {r['text']}" for r in sorted(today, key=lambda r: r['when'])))
            say.append(f"You have {len(today)} reminder{'s' if len(today) != 1 else ''} today.")
        rows = self.tasks_for(now.date())
        if rows:
            lines.append(f"My tasks today ({len(rows)}): " + ", ".join(tk["text"] + (" (overdue)" if tag.startswith("overdue") else "")
                                                               for tk, done, tag in rows[:6]) + ("…" if len(rows) > 6 else ""))
            say.append(f"You have {len(rows)} task{'s' if len(rows) != 1 else ''} today.")
        for title, topic in (("Top news", None), ("Tech news", "technology")):
            try:
                news = self.fetch_news(topic, 3)
            except Exception:
                news = []
            if news:
                lines += ["", title + ":"] + [f"{i}. {h}\n   {u}" for i, (h, u) in enumerate(news, 1)]
                if topic is None:
                    say.append("Top story: " + re.sub(r"\s*\([^)]*\)$", "", news[0][0]) + ".")
        lines += ["", "Internships (live searches, fresh every day):"] + [f"- {n}\n  {u}" for n, u in self.internship_links()[:3]]
        lines += ["", "Have a good day. Say 'I finished today's task' when you're done."]
        return reply("\n".join(lines), " ".join(say) + " The full briefing is on screen.")

    def briefing(self, t, raw):
        if not re.match(r"^(?:good morning|gm|morning|morning briefing|(?:my |daily |today'?s )?briefing|brief me|what'?s new today|morning update)$", t):
            return None
        out = self.morning_briefing()
        self._mark_briefed()
        return out

    def _mark_briefed(self):
        state = read_json("briefing_state.json", {}) or {}
        state["last"] = date.today().isoformat()
        write_json("briefing_state.json", state)

    def morning_due(self):
        """True once a day, at morning_briefing_time (or the first time Vega runs after it, before noon)."""
        m = re.match(r"^(\d{1,2}):(\d{2})$", str(self.cfg.get("morning_briefing_time") or ""))
        if not m:
            return False
        now = datetime.now()
        if (now.hour, now.minute) < (int(m.group(1)), int(m.group(2))) or now.hour >= 12:
            return False
        state = read_json("briefing_state.json", {}) or {}
        if state.get("last") == date.today().isoformat():
            return False
        self._mark_briefed()
        return True

    def news(self, t, raw):
        cricket = re.search(r"\bcricket\b|\bmatch score\b|\bipl\b", t)
        if not (re.search(r"\bnews\b|\bheadlines\b", t) or cricket):
            return None
        m = re.search(r"news (?:about|on|for|from)\s+(.+)$", t)
        if m:
            topic = m.group(1).strip()
        else:
            m2 = re.match(r"^(.*?)\s*\b(?:news|headlines)\b", t)
            topic = m2.group(1).strip() if m2 else ""
            filler = r"^(?:(?:give|tell|show|read) me|what'?s|what is|what are|any|some|the|latest|today'?s|todays|top|breaking|me)\b\s*"
            while re.match(filler, topic):
                topic = re.sub(filler, "", topic, count=1)
        topic = {"tech": "technology", "sport": "sports"}.get(topic, topic)
        if topic in ("", "india", "indian"):
            topic = None
        if cricket:
            topic = "cricket"
        items = self.fetch_news(topic)
        if not items:
            return reply("I couldn't find any news right now.")
        head = f"{'Cricket' if cricket else (topic.capitalize() if topic else 'Top')} news:"
        lines = [f"{i}. {title}\n   {link}" for i, (title, link) in enumerate(items, 1)]
        say = head + " " + ". ".join(re.sub(r"\s*\([^)]*\)$", "", x[0]) for x in items[:3]) + "."
        note = "\n(For live scores, open the link. I only get headlines.)" if cricket else ""
        return reply(head + "\n" + "\n".join(lines) + note, say)

    def wikipedia(self, t, raw):
        m = re.match(r"^(?:who (?:is|was|are|were)|tell me about|what do you know about|search wikipedia for|wikipedia|wiki)\s+(.+)$", t)
        if not m:
            return None
        q = m.group(1).strip()
        if q in ("you", "yourself", "me", "myself") or q.startswith(("my ", "your ")):
            return None
        try:
            s = http_get("https://en.wikipedia.org/w/api.php", {
                "action": "query", "list": "search", "srsearch": q, "format": "json", "srlimit": 1}).json()
            hits = s.get("query", {}).get("search", [])
            if not hits:
                return None
            title = hits[0]["title"]
            summ = http_get("https://en.wikipedia.org/api/rest_v1/page/summary/" +
                            urllib.parse.quote(title.replace(" ", "_"))).json()
        except Exception:
            return None  # no internet: let the AI answer instead
        extract = (summ.get("extract") or "").strip()
        if not extract:
            return None
        sentences = re.split(r"(?<=[.!?])\s+", extract)
        short = " ".join(sentences[:3])
        link = (summ.get("content_urls", {}).get("desktop", {}) or {}).get("page", "")
        return reply(f"{title}: {short}\n(From Wikipedia: {link})", short)

    # ---------------- open apps / sites, search, play
    def search_and_play(self, t, raw):
        m = re.match(r"^(?:search|look up|google)\s+(?:on\s+)?youtube\s+(?:for\s+)?(.+)$", t) or \
            re.match(r"^play\s+(.+?)(?:\s+on\s+youtube)?$", t)
        if m and not re.search(r"^play\s+(?:a\s+)?game", t):
            q = m.group(1).strip()
            webbrowser.open("https://www.youtube.com/results?search_query=" + urllib.parse.quote(q))
            return reply(f"Opening YouTube for: {q}. Click the first video to play.", f"Opening YouTube for {q}.")
        m = re.match(r"^(?:search|google|look up)(?:\s+google)?(?:\s+for)?\s+(.+)$", t)
        if m:
            q = m.group(1).strip()
            webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote(q))
            return reply(f"Searching Google for: {q}", f"Searching Google for {q}.")
        return None

    # ---------------- contacts + WhatsApp (opens the chat; you press call yourself)
    def load_contacts(self):
        c = read_json("contacts.json", {})
        return c if isinstance(c, dict) else {}

    def find_contact(self, name):
        contacts = self.load_contacts()
        key = name.strip().lower()
        key = re.sub(r"^(my|the)\s+", "", key)
        if key in contacts:
            return contacts[key]
        close = difflib.get_close_matches(key, list(contacts), n=1, cutoff=0.75)
        return contacts[close[0]] if close else None

    def contacts(self, t, raw):
        m = re.match(r"^(?:add|save|new)\s+(?:a\s+)?contact\s+(.+?)\s+(\+?\d[\d\s-]{8,})$", t)
        if m:
            name = keep_case(m.group(1).strip(" ,:"), raw)
            digits = re.sub(r"\D", "", m.group(2))
            if len(digits) == 10:
                digits = "91" + digits  # Indian number without country code
            if not 11 <= len(digits) <= 15:
                return reply("That number doesn't look right. Use the full number, like: add contact Amma 98765 43210")
            c = self.load_contacts()
            c[name.lower()] = {"name": name, "phone": digits}
            write_json("contacts.json", c)
            return reply(f"Saved {name}. Now say: call {name} on WhatsApp", f"Saved {name}.")
        m = re.match(r"^(?:remove|delete|forget)\s+contact\s+(.+)$", t)
        if m:
            c = self.load_contacts()
            hit = self.find_contact(m.group(1))
            if not hit:
                return reply(f"I don't have a contact called {m.group(1)}.")
            c.pop(hit["name"].lower(), None)
            write_json("contacts.json", c)
            return reply(f"Removed {hit['name']} from your contacts.")
        if re.match(r"^(?:show |list )?(?:my |all )?contacts$", t):
            c = self.load_contacts()
            if not c:
                return reply("You have no contacts saved. Add one with: add contact Amma 98765 43210")
            return reply("Your contacts:\n" + "\n".join(f"{v['name']}" for v in sorted(c.values(), key=lambda v: v["name"].lower())),
                         f"You have {len(c)} contacts. They're on screen.")
        # "open WhatsApp and call Akka", "go to whatsapp then message Ravi", "on whatsapp call Amma"
        t = re.sub(r"^(?:(?:open|launch|start|go to)\s+whatsapp|on\s+whatsapp|in\s+whatsapp)\s*(?:and|then|to|,)?\s+(?=(?:video\s+|voice\s+)?call|message|text|chat)", "", t)
        m = re.match(r"^(?:(whatsapp|video|voice)\s+)?call\s+(.+?)(?:\s+(?:on|in|through|using)\s+whatsapp)?$", t) or \
            re.match(r"^(?:open\s+)?(?:my\s+)?(?:whatsapp\s+)?chat\s+with\s+(.+)()$", t) or \
            re.match(r"^(?:message|whatsapp|text)\s+(.+)()$", t)
        if not m:
            return None
        name = m.group(2) if m.re.pattern.startswith("^(?:(whatsapp") else m.group(1)
        name = keep_case(name.strip(), raw)
        video = t.startswith("video")
        who = self.find_contact(name)
        if not who:
            return reply(f"I don't have {name} in your contacts yet. Add them first:\n"
                         f"add contact {name} 98765 43210   (use their real number)\n"
                         "Numbers stay only on this laptop, in contacts.json.",
                         f"I don't have {name} yet. Add them with: add contact, then the name and number.", unknown=True)
        if not IS_WINDOWS:
            return reply("This only works on Windows with the WhatsApp app.")
        subprocess.Popen(["cmd", "/c", "start", "", f"whatsapp://send?phone={who['phone']}"], creationflags=NO_WINDOW)
        what = "call" if "call" in t else "chat"
        tip = f"Press the {'video' if video else 'phone'} button at the top to call." if what == "call" else "Type your message there."
        return reply(f"Opening your WhatsApp chat with {who['name']}. {tip}\n"
                     "(For your safety I only open the chat. You press call or send yourself.)",
                     f"Opening WhatsApp with {who['name']}. {tip}")

    def sites_command(self, t, raw):
        """Teach Vega new websites: 'add site srm portal https://...'. List them: 'what can you open'."""
        m = re.match(r"^(?:add|save|remember)\s+(?:a\s+|the\s+|my\s+)?(?:website|site|link)\s+(?:called\s+|named\s+)?(.+?)\s+(?:as\s+|at\s+|is\s+|=\s*)?"
                     r"(https?://\S+|www\.\S+|[a-z0-9-]+(?:\.[a-z0-9-]+)+\S*)$", t)
        if m:
            name = m.group(1).strip(" ,:")
            url = keep_case(m.group(2), raw)
            if not url.lower().startswith(("http://", "https://")):
                url = "https://" + url
            cfg = read_json("config.json", {}) or {}
            sites = cfg.get("sites") if isinstance(cfg.get("sites"), dict) else {}
            sites[name] = url
            cfg["sites"] = sites
            write_json("config.json", cfg)
            self.cfg["sites"][name] = url
            return reply(f"Saved. Now say 'open {name}' and I'll open {url}", f"Saved. Now say open {name}.")
        m = re.match(r"^(?:remove|delete|forget)\s+(?:the\s+)?(?:website|site|link)\s+(.+)$", t)
        if m:
            name = m.group(1).strip()
            cfg = read_json("config.json", {}) or {}
            if isinstance(cfg.get("sites"), dict):
                cfg["sites"].pop(name, None)
                write_json("config.json", cfg)
            self.cfg["sites"].pop(name, None)
            return reply(f"Removed {name}.")
        if re.search(r"^(?:what can you open|what (?:apps|sites|websites) (?:can you open|do you know)|(?:list|show) (?:my |all )?(?:apps|sites|websites)|my (?:apps|sites|websites))$", t):
            apps = ", ".join(sorted(set(list(self.cfg["apps"]) + [a["name"] for a in self.app_index()]), key=str.lower))
            sites = ", ".join(sorted(self.cfg["sites"]))
            return reply(f"Apps I can open:\n{apps}\n\nWebsites I can open:\n{sites}\n\n"
                         "Teach me a new website: add site NAME https://address",
                         "I can open lots of apps and websites. The list is on screen.")
        return None

    def app_index(self):
        """Every app in your Start menu (from Windows' Get-StartApps), cached in apps_index.json."""
        data = read_json("apps_index.json", [])
        return [a for a in data if isinstance(a, dict) and a.get("name") and a.get("id")] if isinstance(data, list) else []

    def refresh_app_index(self):
        if not IS_WINDOWS:
            return
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command",
                                "Get-StartApps | Select-Object Name, AppID | ConvertTo-Json -Compress"],
                               capture_output=True, text=True, timeout=60, creationflags=NO_WINDOW)
            items = json.loads(r.stdout or "[]")
            if isinstance(items, dict):
                items = [items]
            apps = [{"name": str(a.get("Name", "")).strip(), "id": str(a.get("AppID", "")).strip()} for a in items]
            apps = [a for a in apps if a["name"] and a["id"] and not re.search(r"uninstall|readme|help|documentation", a["name"], re.I)]
            if apps:
                write_json("apps_index.json", apps)
        except Exception:
            pass

    def find_installed_app(self, name):
        name = name.replace(" plus plus", "++").replace(" sharp", "#")
        apps = self.app_index()
        if not apps:
            return None
        low = {a["name"].lower(): a for a in apps}
        if name in low:
            return low[name]
        starts = [a for n, a in low.items() if n.startswith(name + " ") or n.replace(" ", "") == name.replace(" ", "")]
        if starts:
            return starts[0]
        close = difflib.get_close_matches(name, list(low), n=1, cutoff=0.75)
        if close:
            return low[close[0]]
        contains = [a for n, a in low.items() if len(name) >= 4 and name in n]
        return contains[0] if len(contains) == 1 else None

    def open_thing(self, t, raw):
        m = re.match(r"^(?:open|launch|start|run)\s+(?:up\s+)?(?:the\s+|my\s+)?(.+?)(?:\s+(?:app|application|website|site|page))?$", t)
        if not m:
            return None
        name = m.group(1).strip()
        if re.search(r"\b(diary|journal|document|doc|file|pdf|to-?do|todo|reminders?)\b", name):
            return None
        apps, sites = self.cfg["apps"], self.cfg["sites"]
        if name not in apps and name not in sites:
            close = difflib.get_close_matches(name, list(apps) + list(sites), n=1, cutoff=0.8)
            if close:
                name = close[0]
        if name in sites:
            webbrowser.open(sites[name])
            return reply(f"Opening {name}.")
        if name in apps:
            if not IS_WINDOWS:
                return reply("Opening apps only works on Windows.")
            target = apps[name]
            subprocess.Popen(["cmd", "/c", "start", "", target], creationflags=NO_WINDOW)
            return reply(f"Opening {name}.")
        if re.match(r"^[a-z0-9-]+(\.[a-z0-9-]+)+$", name):
            webbrowser.open("https://" + name)
            return reply(f"Opening {name}.")
        app = self.find_installed_app(name)
        if app and IS_WINDOWS:
            subprocess.Popen(["explorer.exe", "shell:AppsFolder\\" + app["id"]], creationflags=NO_WINDOW)
            return reply(f"Opening {app['name']}.")
        return reply(f"I couldn't find an app or website called '{name}'. If it's a website, teach me with:  "
                     f"add site {name} https://its-address\n(Say 'what can you open' to see everything I know.)",
                     f"I couldn't find {name}. The way to teach me is on screen.", unknown=True)

    # ---------------- diary
    def diary_file(self, day):
        return here("diary", day.isoformat() + ".txt")

    def diary_append(self, text):
        with open(self.diary_file(date.today()), "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%I:%M %p').lstrip('0')}] {text.strip()}\n")

    def diary_command(self, t, raw):
        if re.search(r"\b(close|end|stop|finish|save|exit)\s+(?:my\s+|the\s+)?(diary|journal)\b|that'?s all for (today|the diary|my diary)", t):
            if not self.diary_mode:
                return reply("Your diary isn't open. Say 'open my diary' to start.")
            self.diary_mode = False
            return reply("Saved in your diary for today. Sleep well, Hemanth." if datetime.now().hour >= 20
                         else "Saved in your diary for today.")
        if re.search(r"\b(start|open|begin|write in|write)\s+(?:my\s+|the\s+|in\s+my\s+)?(diary|journal)\b|let'?s write (?:my |in my )?(diary|journal)|^(diary|journal) time$", t):
            self.diary_mode = True
            return reply("Your diary is open. Tell me about your day, as much or as little as you like. "
                         "Everything you say goes into today's page. Say 'close diary' when you're done.",
                         "Your diary is open. Tell me about your day. Say close diary when you're done.")
        m = re.match(r"^(?:diary|journal|dear diary)[:,]?\s+(.+)$", raw.strip(), flags=re.I)
        if m and not re.match(r"^(diary|journal)\s+(time|for|from)\b", t):
            self.diary_append(m.group(1))
            return reply("Added to today's diary.")
        m = re.search(r"\b(?:read|show|open)\s+(?:me\s+)?(?:my\s+|the\s+)?(?:diary|journal)(?:\s+(?:for|from|of|on))?\s*(today|yesterday|\d{4}-\d{2}-\d{2})?$", t) or \
            re.search(r"what did i write (?:in my diary )?(today|yesterday)", t)
        if m:
            which = (m.group(1) or "today")
            day = date.today() - timedelta(days=1) if which == "yesterday" else (
                date.fromisoformat(which) if re.match(r"\d{4}-", which) else date.today())
            try:
                with open(self.diary_file(day), "r", encoding="utf-8") as f:
                    content = f.read().strip()
            except OSError:
                content = ""
            if not content:
                return reply(f"There's nothing in your diary for {fmt_day(day)}.")
            return reply(f"Your diary for {day.strftime('%A %d %B')}:\n{content}", f"Here's your diary for {fmt_day(day)}. It's on screen.")
        return None

    # ---------------- documents
    def doc_folder(self):
        return here(self.cfg["documents_folder"])

    def list_docs(self):
        ok = (".pdf", ".txt", ".md", ".docx", ".csv", ".py", ".sh", ".yaml", ".yml", ".json", ".log")
        try:
            return sorted(f for f in os.listdir(self.doc_folder()) if f.lower().endswith(ok))
        except OSError:
            return []

    @staticmethod
    def read_document(path, limit=6000):
        low = path.lower()
        if low.endswith(".pdf"):
            from pypdf import PdfReader
            reader = PdfReader(path)
            text = ""
            for page in reader.pages:
                text += (page.extract_text() or "") + "\n"
                if len(text) > limit:
                    break
        elif low.endswith(".docx"):
            import docx
            text = "\n".join(p.text for p in docx.Document(path).paragraphs)
        else:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                text = f.read(limit + 1)
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text).strip()
        cut = len(text) > limit
        return text[:limit], cut

    def load_document(self, path):
        """Open a document (from the documents folder or the Attach button) and summarise it."""
        name = os.path.basename(path)
        text, cut = self.read_document(path)
        if not text:
            return reply(f"I couldn't read any text in {name}. If it's a scanned PDF, it has no text for me to read.")
        self.active_doc = (name, text)
        note = " It's long, so I read the first part only." if cut else ""
        return {"ask": f"Summarise the document '{name}' for me in 5 short bullet points, then tell me in one line what it's for.",
                "instruction": f"I just opened '{name}'.{note} I may ask questions about it next.", "doc": name}

    def documents(self, t, raw):
        if re.search(r"^(?:list|show|what are)\s+(?:my\s+|the\s+|all\s+)?(?:documents|docs|files|pdfs)$|^what (?:documents|files) do (?:i|you) have", t):
            docs = self.list_docs()
            if not docs:
                return reply(f"Your documents folder is empty. Put files in:\n{self.doc_folder()}\n"
                             "(PDF, Word .docx, .txt, .md). Or use the Attach button.",
                             "Your documents folder is empty. The folder path is on screen.")
            return reply("Your documents:\n" + "\n".join(f"{i}. {d}" for i, d in enumerate(docs, 1)),
                         f"You have {len(docs)} documents. They're on screen.")
        if re.search(r"^(?:close|forget|done with|stop reading)\s+(?:the\s+|my\s+|this\s+)?(?:document|doc|file|pdf)$", t):
            if not self.active_doc:
                return reply("No document is open.")
            name = self.active_doc[0]
            self.active_doc = None
            return reply(f"Closed {name}.")
        m = re.match(r"^(?:summari[sz]e|read|open|load|study)\s+(?:my\s+|the\s+)?(?:document|doc|file|pdf)?\s*(?:called\s+|named\s+)?(.+)$", t)
        if not m:
            return None
        want = m.group(1).strip()
        docs = self.list_docs()
        if not docs:
            return None
        stems = {os.path.splitext(d)[0].lower().replace("_", " ").replace("-", " "): d for d in docs}
        pick = None
        for stem, d in stems.items():
            if want == stem or want in stem or want == d.lower():
                pick = d
                break
        if not pick:
            close = difflib.get_close_matches(want, list(stems), n=1, cutoff=0.6)
            pick = stems[close[0]] if close else None
        if not pick:
            if re.search(r"\b(document|doc|file|pdf)\b", t):
                return reply(f"I couldn't find '{want}' in your documents. Say 'list my documents' to see them.")
            return None
        return self.load_document(os.path.join(self.doc_folder(), pick))

    # ---------------- 24-week plan
    def load_plan(self):
        p = read_json("plan.json", None)
        return p if isinstance(p, dict) and "weeks" in p else None

    def plan_shift(self):
        try:
            return int((read_json("plan_settings.json", {}) or {}).get("shift", 0))
        except (TypeError, ValueError, AttributeError):
            return 0

    def plan_day(self, plan, index):
        if index < 0 or index >= len(plan["weeks"]) * 7:
            return None
        week = plan["weeks"][index // 7]
        day = week["days"][index % 7]
        when = date.fromisoformat(plan["start"]) + timedelta(days=index + self.plan_shift())
        return {"index": index, "label": f"Week {index // 7 + 1}, Day {index % 7 + 1}", "topic": week["topic"],
                "title": day["title"], "steps": day["steps"], "date": when, "week": week}

    def today_index(self, plan):
        return (date.today() - date.fromisoformat(plan["start"])).days - self.plan_shift()

    def describe_day(self, d, heading):
        lines = [f"{heading}: {d['label']} ({d['topic']}), {d['date'].strftime('%a %d %b')}", f"  {d['title']}"]
        lines += [f"  {n}. {s}" for n, s in enumerate(d["steps"], 1)]
        if d["index"] % 7 == 0:
            lines += [f"  Coursera: {d['week']['coursera']}", f"  YouTube: {d['week']['youtube']}"]
        return "\n".join(lines), f"{heading} is {d['label']}: {d['title']}. It has {len(d['steps'])} steps. They're on screen."

    def plan_context(self):
        plan = self.load_plan()
        if not plan:
            return ""
        d = self.plan_day(plan, self.today_index(plan))
        if not d:
            return ""
        return f"My study task today is {d['label']} ({d['topic']}): {d['title']}. Steps: " + "; ".join(d["steps"]) + "."

    def plan(self, t, raw):
        if not re.search(r"\b(task|plan|schedule|study|week|quiz|test me)\b", t):
            return None
        plan = self.load_plan()
        if plan is None:
            if re.search(r"today|tomorrow|this week|quiz me|move my plan|reset my plan", t):
                return reply("I can't find plan.json. Put it in the same folder as vega_app.py.")
            return None
        m = re.search(r"move (?:my |the )?(?:plan|schedule) (back|forward|ahead)(?: by)? (\w+) days?", t)
        if m:
            n = to_number(m.group(2))
            if not n or n > 30:
                return reply("Tell me a number of days between 1 and 30, like: move my plan back 3 days.")
            shift = self.plan_shift() + (n if m.group(1) == "back" else -n)
            write_json("plan_settings.json", {"shift": shift})
            d = self.plan_day(plan, max(0, min(len(plan["weeks"]) * 7 - 1, self.today_index(plan))))
            screen, _ = self.describe_day(d, "Today is now")
            msg = f"Done. Your plan moved {m.group(1)} {n} day{'s' if n != 1 else ''}."
            return reply(msg + "\n" + screen + "\n(Your ticks stay on the same plan days.)",
                         msg + f" Today is now {d['label']}: {d['title']}.")
        if re.search(r"reset (?:my |the )?(?:plan|schedule)", t):
            write_json("plan_settings.json", {"shift": 0})
            return reply("Done. Your plan is back to the original dates.")
        idx = self.today_index(plan)
        if "tomorrow" in t and re.search(r"task|plan|study", t):
            d = self.plan_day(plan, idx + 1)
            if not d:
                return reply("There's no plan day for tomorrow.")
            return reply(*self.describe_day(d, "Tomorrow"))
        if re.search(r"today'?s (task|plan)|(task|plan|study) (for )?today|what (should|do) i study|^my task$|what'?s my task|what is my task", t):
            if idx < 0:
                first = self.plan_day(plan, 0)["date"].strftime("%A %d %B")
                return reply(f"Your plan hasn't started yet. Day 1 is on {first}.")
            d = self.plan_day(plan, idx)
            if not d:
                return reply("You've reached the end of the 24-week plan. Well done!")
            screen, say = self.describe_day(d, "Today")
            if self.is_done(idx):
                return reply(screen + "\nStatus: done ✓", say + " You've already finished it.")
            return reply(screen + "\nWhen you finish, say: I finished today's task.", say)
        if re.search(r"this week'?s? (plan|tasks?)|^this week$|what'?s (on )?this week|week'?s plan", t):
            w = max(0, min(len(plan["weeks"]) - 1, idx // 7))
            week = plan["weeks"][w]
            lines = [f"Week {w + 1}: {week['topic']}"]
            for n, day in enumerate(week["days"]):
                d = self.plan_day(plan, w * 7 + n)
                i = w * 7 + n
                box = "✓" if self.is_done(i) else ("✗" if i < idx else "·")
                mark = "  ← today" if i == idx else ""
                lines.append(f"  {box} Day {n + 1} ({d['date'].strftime('%a %d %b')}): {day['title']}{mark}")
            return reply("\n".join(lines), f"Week {w + 1} is {week['topic']}. The seven days are on screen.")
        if re.search(r"\bquiz me\b|\btest me\b", t):
            days = [self.plan_day(plan, i) for i in range(max(0, idx - 2), max(1, idx + 1))]
            material = "\n".join(f"- {d['title']}: " + "; ".join(d["steps"]) for d in days if d)
            return {"ask": "Quiz me on what I studied in these plan days:\n" + material +
                           "\nAsk ONE short question at a time and wait for my answer. After I answer, tell me if I'm right "
                           "in one sentence, then ask the next one. Stop after 3 questions. Only ask about the commands and "
                           "ideas listed above. If you're not sure of an answer, say so."}
        return None


    # ---------------- progress tracking (your ticks, kept on this laptop in progress.json)
    def progress_data(self):
        data = read_json("progress.json", None)
        if not isinstance(data, dict):
            data = {"done": {"0": "2026-09-22T22:00:00"}, "nudged": ""}  # Day 1 was finished on 22 Sep
            write_json("progress.json", data)
        if not isinstance(data.get("done"), dict):
            data["done"] = {}
        data.setdefault("nudged", "")
        return data

    def is_done(self, i):
        return str(i) in self.progress_data()["done"]

    def set_done(self, i, on=True):
        p = self.progress_data()
        if on:
            p["done"][str(i)] = datetime.now().isoformat(timespec="seconds")
        else:
            p["done"].pop(str(i), None)
        write_json("progress.json", p)

    def streaks(self, idx):
        done = {int(k) for k in self.progress_data()["done"] if str(k).isdigit()}
        i = idx if idx in done else idx - 1
        current = 0
        while i >= 0 and i in done:
            current += 1
            i -= 1
        best = run = 0
        for j in range(0, max(idx, 0) + 1):
            run = run + 1 if j in done else 0
            best = max(best, run)
        return current, best

    def missed(self, plan, idx):
        total = len(plan["weeks"]) * 7
        return [i for i in range(0, min(idx, total)) if not self.is_done(i)]

    @staticmethod
    def short_label(i):
        return f"W{i // 7 + 1} D{i % 7 + 1}"

    def day_ref(self, t, idx):
        """Which plan day the message means: 'week 1 day 3', 'w1d3', 'day 3' (this week), 'yesterday', else today."""
        t = words_to_digits(t)
        m = re.search(r"\bw(?:eek)?\s*(\d{1,2})\s*,?\s*d(?:ay)?\s*(\d)\b", t)
        if m:
            return (int(m.group(1)) - 1) * 7 + int(m.group(2)) - 1
        m = re.search(r"\bday\s*(\d)\b", t)
        if m:
            return max(idx, 0) // 7 * 7 + int(m.group(1)) - 1
        if "yesterday" in t:
            return idx - 1
        return idx

    def progress_summary(self, plan, idx):
        total = len(plan["weeks"]) * 7
        done = sum(1 for k in self.progress_data()["done"] if str(k).isdigit() and 0 <= int(k) < total)
        cur, best = self.streaks(idx)
        w = max(0, min(len(plan["weeks"]) - 1, idx // 7))
        marks = []
        for n in range(7):
            i = w * 7 + n
            marks.append(f"D{n + 1} " + ("✓" if self.is_done(i) else ("▶" if i == idx else ("✗" if i < idx else "·"))))
        missed = self.missed(plan, idx)
        lines = [f"Progress: {done} of {total} days done ({round(done * 100 / total)}%)",
                 f"Streak: {cur} day{'s' if cur != 1 else ''} (best {best})",
                 f"This week (Week {w + 1}, {plan['weeks'][w]['topic']}):  " + "   ".join(marks)]
        if missed:
            names = ", ".join(f"{self.short_label(i)} {self.plan_day(plan, i)['title']}" for i in missed[:4])
            lines.append(f"Carried over: {len(missed)} day{'s' if len(missed) != 1 else ''} ({names}{'…' if len(missed) > 4 else ''})")
            if len(missed) >= 2:
                lines.append(f"To catch up, say: move my plan back {len(missed)} days")
        else:
            lines.append("Nothing carried over. You're on track.")
        say = (f"You've done {done} of {total} days. Your streak is {cur} day{'s' if cur != 1 else ''}. "
               + (f"{len(missed)} day{'s are' if len(missed) != 1 else ' is'} carried over." if missed else "You're on track."))
        return "\n".join(lines), say

    def tracking(self, t, raw):
        progress_q = re.search(r"^(?:show |what'?s |what is |check )?(?:my )?(?:progress|streak|stats)$|how am i doing|how far (?:am i|have i got)|how many days (?:have i |did i )?(?:done|completed|finished)", t)
        missed_q = re.search(r"what did i miss|missed days|days i missed|carried over|pending (?:tasks|days)|what'?s pending|backlog", t)
        undo = re.search(r"^(?:undo|unmark|untick|uncheck)\b|\bnot done\b|\bisn'?t done\b", t)
        done_verb = re.search(r"^(?:i\s*(?:'ve|have)?\s*(?:just\s+|already\s+)?(?:finished|completed|done|did)|finished|completed|complete|done with|mark|tick(?: off)?|check off)\b", t)
        target = re.search(r"\b(?:today|yesterday|task|study|studies|lesson|day\s*\w+|w\d+\s*d\d|week\s*\w+\s*,?\s*day\s*\w+)\b", t)
        quick = re.match(r"^(?:done|task done|today done|done for today|i'?m done for today|today'?s task (?:is )?done|finished today'?s task)$", t)
        if not (progress_q or missed_q or quick or (undo and target) or (done_verb and target)):
            return None
        if re.search(r"\b(to-?do|todo|to do|reminder|diary|document)\b", t):
            return None
        plan = self.load_plan()
        if plan is None:
            return reply("I can't find plan.json. Put it in the same folder as vega_app.py.")
        idx = self.today_index(plan)
        total = len(plan["weeks"]) * 7
        if progress_q:
            return reply(*self.progress_summary(plan, idx))
        if missed_q:
            missed = self.missed(plan, idx)
            if not missed:
                return reply("You haven't missed anything. Every past day is done.")
            lines = [f"{self.short_label(i)} ({self.plan_day(plan, i)['date'].strftime('%a %d %b')}): {self.plan_day(plan, i)['title']}" for i in missed]
            tip = f"\nTo restart from the first one, say: move my plan back {len(missed)} days" if len(missed) >= 2 else ""
            return reply(f"Carried over ({len(missed)}):\n" + "\n".join(lines) + tip,
                         f"You have {len(missed)} day{'s' if len(missed) != 1 else ''} carried over. They're on screen.")
        i = self.day_ref(t, idx)
        if i < 0 or i >= total:
            return reply("That day isn't in your 24-week plan.")
        d = self.plan_day(plan, i)
        if undo:
            self.set_done(i, False)
            return reply(f"Okay, {d['label']} ({d['title']}) is marked not done.")
        early = i > idx
        already = self.is_done(i)
        self.set_done(i, True)
        cur, _ = self.streaks(idx)
        done = sum(1 for k in self.progress_data()["done"] if str(k).isdigit() and 0 <= int(k) < total)
        missed = self.missed(plan, idx)
        head = f"{d['label']} ({d['title']}) was already done." if already else \
            f"Nice work! {d['label']} ({d['title']}) is done" + (" early." if early else ".")
        extra = f"\nStill carried over: {len(missed)} earlier day{'s' if len(missed) != 1 else ''}. Say 'what did I miss'." if missed else ""
        text = f"{head}\nStreak: {cur} day{'s' if cur != 1 else ''}. {done} of {total} days done ({round(done * 100 / total)}%).{extra}"
        return reply(text, f"{head} Your streak is {cur} day{'s' if cur != 1 else ''}.")

    def study_nudge_due(self):
        """Once a day, at study_nudge_time, remind Hemanth if today's task isn't done."""
        m = re.match(r"^(\d{1,2}):(\d{2})$", str(self.cfg.get("study_nudge_time") or ""))
        if not m:
            return None
        now = datetime.now()
        if (now.hour, now.minute) < (int(m.group(1)), int(m.group(2))):
            return None
        p = self.progress_data()
        today = date.today().isoformat()
        if p.get("nudged") == today:
            return None
        p["nudged"] = today
        write_json("progress.json", p)
        plan = self.load_plan()
        if not plan:
            return None
        idx = self.today_index(plan)
        d = self.plan_day(plan, idx)
        left = [tk["text"] for tk, done, _ in self.tasks_for(date.today()) if not done]
        parts = []
        if d and not self.is_done(idx):
            parts.append(f"You haven't finished today's study task yet: {d['title']}. Even 30 minutes counts.")
        if left:
            parts.append(f"Tasks still open today: {', '.join(left[:5])}.")
        return " ".join(parts) or None


# ---------------------------------------------------------------- reminder clock

class ReminderClock(threading.Thread):
    """Checks reminders every 5 seconds and calls on_due(text) when one is due."""

    def __init__(self, vega, on_due, on_briefing=None):
        super().__init__(daemon=True)
        self.vega, self.on_due, self.on_briefing = vega, on_due, on_briefing

    def run(self):
        while True:
            try:
                for r in self.vega.due_reminders():
                    text = r["text"]
                    if r["late"]:
                        text += f"  (missed — it was due {fmt_day(r['when'])} at {fmt_time(r['when'])})"
                    self.on_due(text)
                nudge = self.vega.study_nudge_due()
                if nudge:
                    self.on_due(nudge)
                if self.on_briefing and self.vega.morning_due():
                    self.on_briefing()
            except Exception:
                pass
            time.sleep(5)
